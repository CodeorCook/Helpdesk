const {chromium}=require('@playwright/test');
const {spawn}=require('child_process');
const assert=require('node:assert/strict');
const path=require('node:path');
const fs=require('node:fs');
const base='http://localhost:5175';const root=path.resolve(__dirname,'..');
const server=spawn(process.execPath,[path.join(root,'node_modules/vite/bin/vite.js'),'--host','localhost','--port','5175'],{cwd:root,windowsHide:true,stdio:'ignore'});
(async()=>{let browser;try{
 for(let n=0;n<100;n++){try{if((await fetch(base)).ok)break}catch{}await new Promise(r=>setTimeout(r,100));if(n===99)throw Error('Vite not ready')}
 browser=await chromium.launch();let cases=0;
 for(const mobile of [false,true])for(const role of ['customer','staff','manager'])for(const mode of ['light','dark']){
  const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:800},isMobile:mobile,hasTouch:mobile});
  await context.addInitScript(mode=>localStorage.setItem('helpdesk-theme',mode),mode);
  await context.route('**/api/v1/**',async route=>{const u=new URL(route.request().url());let body={};
   if(u.pathname==='/api/v1/auth/me')body={user:{id:'1',name:'Kiểm tra giao diện',email:'layout@example.invalid',role,role_label:{customer:'Khách hàng',staff:'Nhân viên hỗ trợ',manager:'Quản lý'}[role]},csrf_token:null};
   else if(u.pathname.endsWith('/overview'))body={total:0,active:0,resolved:0,closed:0,assigned:0,queue:0,recommended:0,team:0,unrouted:0,groups:0,overdue:0,users:0,waiting:0,processing:0,paused:0,by_status:[],by_group:[],by_type:[],by_priority:[]};
   else if(u.pathname.endsWith('/tickets'))body={items:[],total:0,page:1,page_size:10};
   else throw Error('Unexpected API '+u.pathname);
   await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});
  });
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(base+'/'+role);await page.locator('.identity strong').waitFor();
  const header=await page.locator('.dashboard-top').evaluate(e=>({background:getComputedStyle(e).backgroundImage,color:getComputedStyle(e).color,height:e.getBoundingClientRect().height}));
  assert.equal(header.height,80);if(mode==='dark'){assert(header.background.includes('rgb(16, 42, 48)'));assert(header.background.includes('rgb(69, 64, 40)'));assert.equal(header.color,'rgb(224, 239, 239)')}else{assert.equal(header.background,'linear-gradient(130deg, rgb(239, 249, 247), rgb(255, 245, 204))');if(role==='customer')assert.equal(header.background,await page.locator('.sidebar-banner').evaluate(e=>getComputedStyle(e).backgroundImage))}
  await page.screenshot({path:path.join(__dirname,`header-${role}-${mode}-${mobile?'mobile':'desktop'}.png`)});
  await page.locator('.dashboard-main>.container').evaluate(e=>{const long=document.createElement('div');long.style.height='3500px';long.textContent='Chỉ dùng kiểm tra cuộn trang';e.append(long)});
  if(!mobile){
   const initial=await page.locator('.sidebar-footer').boundingBox();assert(initial.y>=0&&initial.y+initial.height<=801);
   await page.evaluate(()=>scrollTo(0,1400));await page.waitForTimeout(100);const after=await page.locator('.sidebar-footer').boundingBox();assert(Math.abs(after.y-initial.y)<1);
   await page.setViewportSize({width:1280,height:520});
   await page.locator('.customer-nav').evaluate(nav=>{const original=nav.firstElementChild;for(let n=0;n<35;n++)nav.append(original.cloneNode(true))});
   const menu=page.locator('.sidebar-menu');assert(await menu.evaluate(e=>e.scrollHeight>e.clientHeight));const before=await page.locator('.sidebar-footer').boundingBox();
   await menu.hover();await page.mouse.wheel(0,700);await page.waitForTimeout(100);assert(await menu.evaluate(e=>e.scrollTop>0));const footer=await page.locator('.sidebar-footer').boundingBox();assert(Math.abs(footer.y-before.y)<1);assert(footer.y+footer.height<=521);
   await page.getByRole('combobox',{name:'Giao diện',exact:true}).selectOption(mode==='light'?'dark':'light');await page.getByRole('combobox',{name:'Giao diện',exact:true}).selectOption(mode);
   await page.locator('.sidebar-footer button').hover();assert(await page.locator('.sidebar-footer button').isVisible());
  }else{
   assert.equal(await page.locator('.sidebar').evaluate(e=>getComputedStyle(e).position),'static');const before=await page.locator('.sidebar').boundingBox();await page.evaluate(()=>scrollTo(0,1200));const after=await page.locator('.sidebar').boundingBox();assert(after.y<before.y-500);
  }
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:path.join(__dirname,`sidebar-${role}-${mode}-${mobile?'mobile':'desktop'}.png`)});assert.deepEqual(errors,[]);await context.close();cases++;console.log('PASS layout '+role+' '+mode+' '+(mobile?'mobile':'desktop'));
 }
 const publicContext=await browser.newContext();const p=await publicContext.newPage();await publicContext.route('**/api/v1/auth/me',r=>r.fulfill({status:401,contentType:'application/json',body:'{"detail":"Unauthenticated layout test"}'}));await p.goto(base+'/login');
 for(const mode of ['light','dark']){await p.getByRole('combobox',{name:'Giao diện',exact:true}).selectOption(mode);const bg=await p.locator('.login-art').evaluate(e=>getComputedStyle(e).backgroundImage);assert(bg.includes('135deg'));assert(!bg.includes('rgb(16, 42, 48)'))}
 await publicContext.close();console.log('PASS '+cases+' role/theme/viewport cases; long-page sticky footer, short viewport/menu scrolling, no horizontal overflow; login gradient unchanged. UI fixtures only; no Backend/DB calls.');
 }finally{if(browser)await browser.close();server.kill()}})().catch(e=>{console.error(e);process.exitCode=1});
