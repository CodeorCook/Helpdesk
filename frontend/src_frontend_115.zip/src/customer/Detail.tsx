import { Conversation } from '../chat/Conversation';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { customerApi, formatDate, type Ticket } from './api';
import { RequestSummary, usesRequestSummary } from './RequestSummary';
import { Completion } from './Completion';
export type DetailData=Ticket&{messages:{id:string;content:string;sender:string;from_customer:boolean;created_at:string}[];messages_truncated:boolean;attachments:{id:string;name:string;mime_type:string;size:number;created_at:string}[];history:{previous:string|null;current:string;created_at:string}[];rating:{stars:number;comment:string|null;created_at:string}|null};
export function TicketDetail(){
 const {id}=useParams();const navigate=useNavigate();const [data,setData]=useState<DetailData|null>(null);const [error,setError]=useState('');
 async function load(){setError('');try{setData(await customerApi<DetailData>(`/tickets/${id}`));}catch(e){setError((e as Error).message);}}
 useEffect(()=>{setData(null);void load();},[id]);
 if (data && usesRequestSummary(data.status)) return <>
   <Link className="text-link" to="/customer/tickets">← Lịch sử yêu cầu</Link>
   <RequestSummary id={data.id} initial={data} close={() => navigate('/customer/tickets', { replace: true })} changed={() => {}}/>
 </>;
 return <><Link className="text-link" to="/customer/tickets">← Lịch sử yêu cầu</Link>{error&&<p role="alert" className="error-box">{error}</p>}{!data&&!error&&<p role="status">Đang tải chi tiết phiếu…</p>}{data&&<><div className="page-heading"><div><span className="eyebrow">PHIẾU #HT-{data.id}</span><h1>{data.title}</h1></div><span className="badge">{data.status_label}</span></div><div className="detail-grid"><div><section className="panel"><h2>Nội dung yêu cầu</h2><p className="preserve-text">{data.description}</p></section><Conversation role="customer" ticketId={data.id} revision={data.status} reload={load}/><Completion data={data} reload={load}/></div><aside><section className="panel"><h2>Thông tin phiếu</h2><dl className="detail-meta">{[['Loại hỗ trợ',data.type_name||'Chưa phân loại'],['Mức ưu tiên',data.priority],['Nhân viên phụ trách',data.assigned_to||'Chưa phân công'],['Ngày tạo',formatDate(data.created_at)],['Cập nhật',formatDate(data.updated_at)]].map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></section><section className="panel"><h2>Lịch sử trạng thái</h2><ol className="timeline">{data.history.map((h,i)=><li key={i}><strong>{h.current}</strong><small>{formatDate(h.created_at)}</small></li>)}</ol></section></aside></div></>}</>;
}
