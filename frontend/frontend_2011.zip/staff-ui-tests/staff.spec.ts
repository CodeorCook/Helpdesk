import { test,expect,type Page } from '@playwright/test';
import { escapeCsvCell } from '../src/manager/reportCsv';

test('CSV escapes untrusted formulas, quotes and line breaks', () => {
  for (const value of ['=1+1', '+1', '-1', '@SUM(1)', '  =1', '\tplain', '\rplain', '\nplain', '＝1']) {
    expect(escapeCsvCell(value)).toBe(`"'${value}"`);
  }
  expect(escapeCsvCell('a,"b"\nc')).toBe('"a,""b""\nc"');
  expect(escapeCsvCell(-20)).toBe('"-20"');
});
type Role='staff'|'customer'|'manager';
const statuses=['MOI','DANG_XU_LY','TAM_DUNG','DA_GIAI_QUYET','DA_DONG','DA_HUY'];
const labels=['Mới','Đang xử lý','Tạm dừng','Đã giải quyết','Đã đóng','Đã hủy'];
function ticket(index:number,scope:string,search=''){
 const code=scope==='queue'?'MOI':statuses[index%statuses.length];
 return {id:String(1000+index),title:`${search||scope} · Phiếu ${index+1}`,description:'Dữ liệu kiểm thử giao diện cô lập',type_id:'6',type_name:'Bảo hành sản phẩm',status:code,status_label:labels[statuses.indexOf(code)],priority:'Trung bình',priority_id:'2',created_at:'2026-11-02T08:00:00+07:00',updated_at:'2026-11-02T08:00:00+07:00',closed_at:null,group_id:'2',group_name:'Bảo hành và bảo trì',assigned_id:scope==='queue'?null:'77',assigned_to:scope==='queue'?null:'Nhân viên giao diện',recommended:scope==='queue'&&index===0,sla_name:null,response_due:null,resolution_due:null,first_response_at:null,resolved_at:null,sla_state:'Chưa cấu hình SLA'};
}
async function fixtures(page:Page,role:Role='staff',options:{mineTotal?:number;denyView?:boolean;uploadError?:boolean}={}){
 const calls:{method:string;url:URL;body:unknown;csrf:string|undefined}[]=[];let conflict=false;let failCreate=false;const accepted=new Set<string>();
 await page.route('**/api/v1/**',async route=>{
  const request=route.request();const url=new URL(request.url());const method=request.method();
  calls.push({method,url,body:request.headers()['content-type']?.includes('application/json')?request.postDataJSON():request.postData(),csrf:request.headers()['x-csrf-token']});
  let body:unknown;let status=200;
  if(url.pathname==='/api/v1/auth/me')body={user:{id:'77',name:'Nhân viên giao diện',email:'staff-layout@example.invalid',role,role_label:role==='staff'?'Nhân viên hỗ trợ':role==='manager'?'Quản lý':'Khách hàng'},csrf_token:null};
  else if(url.pathname==='/api/v1/auth/csrf')body={csrf_token:'ui-fixture-only-csrf'};
  else if(url.pathname==='/api/v1/auth/logout')status=204;
  else if(url.pathname==='/api/v1/staff/overview')body={assigned:17,queue:12,recommended:3,team:25,unrouted:0,groups:2,overdue:2};
  else if(url.pathname==='/api/v1/staff/ticket-types')body=[{id:'6',name:'Bảo hành sản phẩm'}];
  else if(url.pathname==='/api/v1/staff/ticket-statuses')body=statuses.map((code,i)=>({id:String(i+1),code,name:labels[i]}));
  else if(url.pathname==='/api/v1/staff/priorities')body=[{id:'2',name:'Trung bình'}];
  else if(url.pathname==='/api/v1/staff/attachment-policy')body={max_bytes:5242880,max_files:20,extensions:['.txt','.png','.jpg','.pdf']};
  else if(url.pathname==='/api/v1/staff/customers'){
   const query=url.searchParams.get('search');if(query==='old')await new Promise(r=>setTimeout(r,350));
   body=query==='empty'?[]:[{id:'111',name:'Khách hàng hợp lệ'}];
  }
  else if(url.pathname==='/api/v1/staff/tickets'&&method==='POST'){
   await new Promise(r=>setTimeout(r,100));if(failCreate){failCreate=false;status=503;body={detail:'Dịch vụ tạm thời không sẵn sàng. Vui lòng thử lại.'}}else{status=201;body={id:'9001',message:'Đã lập phiếu mới thay khách hàng. Phiếu đang chờ tiếp nhận; chưa phân công.'}}
  }
  else if(url.pathname==='/api/v1/staff/tickets/9001/attachments'&&method==='POST'){
   if(options.uploadError){status=415;body={detail:'Nội dung tệp không hợp lệ.'}}else{status=201;body={id:'88',name:'fixture.txt'}}
  }
  else if(url.pathname==='/api/v1/staff/tickets/9001'){
   if(options.denyView){status=404;body={detail:'Không tìm thấy phiếu.'}}else body={id:'9001'};
  }
  else if(url.pathname==='/api/v1/staff/tickets'){
   const scope=url.searchParams.get('scope')||'queue';const search=url.searchParams.get('search')||'';const p=Number(url.searchParams.get('page')||1);
   if(search==='old')await new Promise(r=>setTimeout(r,350));
   const size=Number(url.searchParams.get('page_size')||10);const total=scope==='mine'?(options.mineTotal??12):25;
   body={items:Array.from({length:Math.max(0,Math.min(size,total-(p-1)*size))},(_,i)=>ticket(i+(p-1)*size,scope,search)).filter(t=>!accepted.has(t.id)),total:total-accepted.size,page:p,page_size:size};
  }
  else if(/^\/api\/v1\/staff\/tickets\/\d+\/accept$/.test(url.pathname)&&method==='POST'){
   const id=url.pathname.split('/').at(-2)!;
   if(conflict){status=409;body={detail:'Phiếu vừa được tiếp nhận. Vui lòng làm mới.'}}else{accepted.add(id);body=ticket(0,'mine')}
  }
  else if(url.pathname==='/api/v1/customer/overview')body={total:0,active:0,resolved:0,closed:0};
  else if(url.pathname==='/api/v1/customer/tickets')body={items:[],total:0,page:1,page_size:10};
  else if(url.pathname==='/api/v1/manager/overview')body={total:0,waiting:0,processing:0,paused:0,resolved:0,closed:0,overdue:0,users:0,groups:0,by_status:[],by_group:[],by_type:[],by_priority:[]};
  else throw new Error('Unexpected API in UI-only fixture: '+url.pathname);
  await route.fulfill({status,contentType:'application/json',...(status===204?{}:{body:JSON.stringify(body)})});
 });
 return {calls,setConflict:()=>{conflict=true},failCreateOnce:()=>{failCreate=true}};
}

for(const theme of ['light','dark'])for(const path of ['/staff','/staff/queue','/staff/mine']){
 test(`${path} · ${theme}: layout, styles, menus and API contract`,async({page},info)=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.addInitScript(mode=>localStorage.setItem('helpdesk-theme',mode),theme);const {calls}=await fixtures(page);await page.goto(path);
  const sidebar=page.locator('.sidebar');await expect(sidebar.getByRole('link',{name:'Yêu cầu chờ tiếp nhận',exact:true})).toBeVisible();await expect(sidebar.getByRole('link',{name:'Đề xuất cho bạn',exact:true})).toHaveCount(0);await expect(sidebar.getByRole('link',{name:'Phiếu trong nhóm',exact:true})).toHaveCount(0);
  if(path==='/staff'){
   await expect(page.getByRole('button',{name:'Làm mới',exact:true})).toHaveCount(0);await expect(page.locator('.staff-stat-assigned h2')).toHaveText('17');await expect(page.locator('.staff-stat-queue h2')).toHaveText('12');await expect(page.locator('.staff-stat-overdue h2')).toHaveText('2');await expect(page.locator('.staff-stat-queue small')).toContainText('3 phiếu ưu tiên');
   const account=(await page.locator('.staff-account-panel').boundingBox())!;const stats=(await page.locator('.staff-stats-grid').boundingBox())!;expect(account.y+account.height).toBeLessThanOrEqual(stats.y);
   const backgrounds=await page.locator('.staff-stat').evaluateAll(items=>items.map(e=>getComputedStyle(e).backgroundColor));expect(new Set(backgrounds).size).toBe(3);
  }else if(path.endsWith('queue')){
   await expect(page.locator('.staff-queue-table tbody tr')).toHaveCount(5);
   await expect(page.locator('.staff-filter-panel')).toHaveCount(0);
   await expect(page.getByText('Ưu tiên cho bạn',{exact:true})).toHaveCount(1);
   await expect(page.getByRole('combobox',{name:'Sắp xếp theo'})).toHaveValue('newest');
  }else{
   await expect(page.locator('.ticket-table tbody tr')).toHaveCount(5);
   const panel=page.locator('.staff-ticket-panel');await expect(panel.locator('.staff-pagination')).toBeVisible();
   const scroller=page.locator('.staff-ticket-scroll');const height=(await scroller.boundingBox())!.height;
   expect(height).toBeGreaterThanOrEqual(330);
   expect(await scroller.evaluate(e=>e.scrollHeight-e.clientHeight)).toBeLessThanOrEqual(1);
   expect(new Set(await panel.locator('td[data-label="Trạng thái"] .staff-status-badge').evaluateAll(items=>items.map(e=>getComputedStyle(e).backgroundColor))).size).toBe(5);
   await expect(panel.locator('thead th')).toHaveText(['Phiếu','Nhóm hỗ trợ','Trạng thái','Mức độ ưu tiên']);
   await expect(page.getByRole('combobox',{name:'Loại hỗ trợ',exact:true})).toHaveCount(0);
   await panel.getByRole('button',{name:'Sau',exact:true}).click();await expect(page.locator('.staff-pagination')).toContainText('Trang 2');await expect(page.locator('.ticket-table tbody tr').first()).toContainText('Phiếu 6');expect(Math.abs((await scroller.boundingBox())!.height-height)).toBeLessThan(1);
   expect(calls.some(c=>c.url.pathname==='/api/v1/staff/tickets'&&c.url.searchParams.get('scope')===(path.endsWith('mine')?'mine':'queue'))).toBeTruthy();
  }
  await expect(page.locator('html')).toHaveAttribute('data-theme',theme);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();expect(errors).toEqual([]);await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:`test-results/staff-ui-${path.split('/').at(-1)}-${theme}-${info.project.name}.png`,fullPage:true});
 });
}

for (const theme of ['light','dark']) test(`mine detail and read receipts · ${theme}`, async ({page}) => {
 await page.addInitScript(mode=>localStorage.setItem('helpdesk-theme',mode),theme);
 const {calls}=await fixtures(page);
 const base=ticket(0,'mine');
 let unread=3;
 let status='DANG_XU_LY';
 let statusCalls=0;
 let acknowledged:string[]=[];
 await page.route('**/api/v1/staff/tickets?*',async route=>{
  const query=new URL(route.request().url()).searchParams;
  calls.push({method:'GET',url:new URL(route.request().url()),body:null,csrf:undefined});
  const pageNumber=Number(query.get('page'));
  const items=[{...base,priority_rank:3,unread_customer_messages:unread},
   {...ticket(1,'mine'),priority_rank:2},{...ticket(2,'mine'),priority_rank:1}];
  await route.fulfill({json:{items,total:7,page:pageNumber,page_size:5}});
 });
 await page.route(/\/api\/v1\/staff\/tickets\/1000(?:\/|$)/,async route=>{
  const path=new URL(route.request().url()).pathname;
  if(path.endsWith('/read')){
   acknowledged=route.request().postDataJSON().message_ids;
   unread=0;
   return route.fulfill({status:204});
  }
  if(path.endsWith('/status')){statusCalls++;status=route.request().postDataJSON().status;}
  const detail={...base,status,status_label:status==='TAM_DUNG'?'Tạm dừng':'Đang xử lý',
   can_process:true,customer:{id:'111',name:'Khách hàng'},attachments:[]};
  if(path.endsWith('/conversation'))return route.fulfill({json:{...detail,
   can_mark_read:true,can_send:true,can_view_internal:true,can_send_internal:true,events:[],has_older:false,
   messages:[{id:'11',sender:'Khách hàng',sender_id:'111',content:'Nội dung khách gửi',created_at:base.created_at,from_customer:true,internal:false},
    {id:'12',sender:'Nhân viên',sender_id:'77',content:'Trao đổi riêng',created_at:base.created_at,internal:true}]}});
  return route.fulfill({json:detail});
 });
 await page.goto('/staff/mine');
 await expect(page.getByText('3 tin nhắn mới từ Khách hàng')).toBeVisible();
 const priority=page.locator('td[data-label="Mức độ ưu tiên"] .staff-status-badge');
 expect(new Set(await priority.evaluateAll(nodes=>nodes.map(node=>getComputedStyle(node).backgroundColor))).size).toBe(3);
 await page.getByLabel('Mã hoặc tiêu đề').fill('bảo hành');
 await page.getByRole('button',{name:'Lọc phiếu'}).click();
 await page.getByRole('combobox',{name:'Sắp xếp theo'}).selectOption('oldest');
 await expect.poll(()=>calls.at(-1)?.url.searchParams.get('sort')).toBe('oldest');
 await page.getByRole('button',{name:'Sau',exact:true}).click();
 await expect.poll(()=>calls.at(-1)?.url.searchParams.get('page')).toBe('2');
 expect(calls.at(-1)?.url.searchParams.get('search')).toBe('bảo hành');
 expect(calls.at(-1)?.url.searchParams.get('sort')).toBe('oldest');
 const link=page.locator('.staff-mine-panel').getByRole('link',{name:/HT-1000/});
 await link.focus();
 await link.press('Space');
 await expect(page).toHaveURL('/staff/tickets/1000');
 await expect(page.getByText('Nội dung khách gửi')).toBeVisible();
 await page.getByText('Nội dung khách gửi').scrollIntoViewIfNeeded();
 await expect.poll(()=>acknowledged).toEqual(['11']);
 const select=page.locator('.chat-header').getByLabel('Cập nhật trạng thái');
 await select.selectOption('TAM_DUNG');
 const dialog=page.getByRole('dialog',{name:'Xác nhận cập nhật trạng thái'});
 await expect(dialog).toContainText('Đang xử lý → Tạm dừng');
 expect(statusCalls).toBe(0);
 await dialog.getByRole('button',{name:'Hủy',exact:true}).click();
 await expect(select).toHaveValue('');
 await select.selectOption('TAM_DUNG');
 await dialog.getByRole('button',{name:'Xác nhận',exact:true}).click();
 await expect(page.locator('.chat-header')).toContainText('Tạm dừng');
 expect(statusCalls).toBe(1);
 await expect(page.getByRole('heading',{name:/Xử lý phiếu|Phân loại và ưu tiên|Chuyển trong nhóm|Lịch sử trạng thái|Lịch sử phân công/})).toHaveCount(0);
 await expect(page.getByText('Phản hồi đầu',{exact:true})).toHaveCount(0);
 await expect(page.locator('html')).toHaveAttribute('data-theme',theme);
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
 await page.getByRole('navigation',{name:'Đường dẫn điều hướng'}).getByRole('link',{name:'Phiếu của tôi'}).click();
 await expect(page.locator('.staff-unread-badge')).toHaveCount(0);
 await page.locator('.staff-mine-panel tbody tr').first().getByText('Bảo hành và bảo trì').click();
 await expect(page).toHaveURL('/staff/tickets/1000');
});

test('manager conversation can reply only on the internal tab', async ({page}) => {
 await fixtures(page,'manager');
 const base=ticket(0,'mine');
 const detail={...base,status:'DANG_XU_LY',status_label:'Đang xử lý',assignment_id:'1',
  customer:{id:'111',name:'Khách hàng'},history:[],assignments:[],attachments:[]};
 let body:unknown;
 let assignment:unknown;
 await page.route('**/api/v1/manager/groups?*',route=>route.fulfill({json:{items:[{id:'2',name:'Bảo hành',active:true}],total:1}}));
 await page.route('**/api/v1/manager/groups/2/eligible-employees',route=>route.fulfill({json:[]}));
 await page.route(/\/api\/v1\/manager\/tickets\/1000(?:\/|$)/,async route=>{
  const path=new URL(route.request().url()).pathname;
  if(path.endsWith('/assignment')){
   assignment=route.request().postDataJSON();
   return route.fulfill({json:detail});
  }
  if(path.endsWith('/internal-messages')){
   body=route.request().postDataJSON();
   return route.fulfill({status:201,json:{id:'15'}});
  }
  if(path.endsWith('/conversation'))return route.fulfill({json:{...detail,
   can_view_internal:true,can_send_internal:true,can_send:false,has_older:false,events:[],
   messages:body?[{id:'15',sender_id:'77',sender:'Quản lý',content:'Kiểm tra khung ghế',
    created_at:base.created_at,internal:true}]:[]}});
  return route.fulfill({json:detail});
 });
 await page.goto('/manager/tickets/1000');
 await expect(page.getByRole('navigation',{name:'Đường dẫn điều hướng'}).getByRole('link',{name:'Giám sát phiếu'})).toHaveAttribute('href','/manager/tickets');
 await expect(page.getByRole('heading',{name:'Áp SLA có xác nhận'})).toHaveCount(0);
 await expect(page.locator('.detail-grid > div > section h2')).toHaveText(['Nội dung yêu cầu','Hội thoại hỗ trợ']);
 await expect(page.getByText('Chế độ giám sát · Chỉ đọc')).toBeVisible();
 await expect(page.getByLabel('Nội dung trao đổi')).toHaveCount(0);
 await page.getByRole('tab',{name:'Trao đổi với Nhân viên'}).click();
 await page.getByLabel('Nội dung trao đổi').fill('Kiểm tra khung ghế');
 await page.getByRole('button',{name:'Gửi nội dung'}).click();
 await expect(page.getByText('Kiểm tra khung ghế',{exact:true})).toBeVisible();
 expect(body).toEqual({content:'Kiểm tra khung ghế'});
 await expect(page.getByRole('button',{name:'Đính kèm tệp công khai'})).toHaveCount(0);
 await page.getByRole('tab',{name:'Trao đổi với Khách hàng'}).click();
 await expect(page.getByText('Kiểm tra khung ghế',{exact:true})).toHaveCount(0);
 await page.getByRole('button',{name:'Phân công lại',exact:true}).click();
 const modal=page.getByRole('dialog',{name:'Phân công lại phiếu'});
 await expect(modal).toContainText('#HT-1000');
 await modal.getByLabel('Phương án nhận phiếu').selectOption('QUEUE');
 await modal.getByLabel('Lý do điều phối').fill('Chờ nhóm tiếp nhận');
 await modal.getByRole('button',{name:'Xác nhận phân công lại'}).click();
 await expect(modal).toHaveCount(0);
 expect(assignment).toMatchObject({group_id:'2',employee_id:null,expected_assignment_id:'1',reason:'Chờ nhóm tiếp nhận'});
});

test('queue response clock crosses 50 percent and zero', async ({page}) => {
 await fixtures(page);
 const start = Date.parse('2026-11-02T08:00:00+07:00');
 await page.clock.install({time: start});
 await page.clock.pauseAt(start + 1000);
 await page.route('**/api/v1/staff/tickets?*', route => route.fulfill({json:{
  items:[
   {...ticket(0,'queue'),sla_name:'SLA',response_due:new Date(start + 4000).toISOString()},
   {...ticket(1,'queue'),sla_name:'SLA',response_due:new Date(start + 500).toISOString()},
   ticket(2,'queue'),
  ],
  total:3,page:1,page_size:5,soon:0,overdue:1,server_now:new Date(start + 1000).toISOString(),
 }}));
 await page.goto('/staff/queue');
 const rows = page.locator('.staff-queue-table tbody tr');
 await expect(rows.nth(0)).toContainText('00:03');
 await expect(rows.nth(1)).toContainText('Đã quá hạn');
 await expect(rows.nth(2)).toContainText('Chưa có hạn');
 await page.clock.runFor(1000);
 await expect(rows.nth(0)).toContainText('Sắp đến hạn');
 await expect(rows.nth(0)).toContainText('00:02');
 await page.clock.runFor(2000);
 await expect(rows.nth(0)).toContainText('Đã quá hạn');
 await expect(rows.nth(0)).toContainText('00:00');
});

for (const theme of ['light','dark']) test(`queue sorting and request review · ${theme}`, async ({page}) => {
 await page.addInitScript(mode => localStorage.setItem('helpdesk-theme', mode), theme);
 const {calls}=await fixtures(page);
 let approved=false;
 let approval:unknown;
 const original={...ticket(0,'queue'), customer:{id:'111',name:'Khách thử'}, description:'Sofa bi goy khong dau',attachments:[],history:[],assignments:[]};
 await page.route(/\/api\/v1\/staff\/tickets\/1000(?:\/|$)/,async route=>{
   const path=new URL(route.request().url()).pathname;
   if(path.endsWith('/approve')){
     approved=true;
     approval=route.request().postDataJSON();
   }
   if(path.endsWith('/conversation')) return route.fulfill({json:{messages:[],attachments:[],events:[],has_older:false}});
   return route.fulfill({json:{...original,...(approved?{status:'DANG_XU_LY',status_label:'Đang xử lý',title:'Sofa chuẩn hóa'}:{})}});
 });
 await page.goto('/staff/recommended');
 await expect(page).toHaveURL('/staff/queue');
 await expect(page.locator('.staff-queue-cards')).toContainText('25');
 await expect(page.locator('.staff-filter-panel')).toHaveCount(0);
 await page.getByRole('button',{name:'Sau',exact:true}).click();
 await expect(page.locator('.staff-pagination')).toContainText('Trang 2');
 await page.getByRole('combobox',{name:'Sắp xếp theo'}).selectOption('due');
 await expect(page.locator('.staff-pagination')).toContainText('Trang 1');
 expect(calls.at(-1)?.url.searchParams.get('sort')).toBe('due');
 await page.locator('.staff-queue-table tbody tr').first().getByText('Bảo hành sản phẩm').click();
 await expect(page).toHaveURL('/staff/requests/1000');
 await page.goto('/staff/tickets/1000');
 await expect(page).toHaveURL('/staff/requests/1000');
 await expect(page.getByText(original.description,{exact:true})).toBeVisible();
 await expect(page.getByRole('button',{name:'Sao chép nội dung'})).toHaveCount(0);
 await expect(page.getByRole('link',{name:'Quay lại danh sách'})).toHaveCount(0);
 await expect(page.getByRole('navigation',{name:'Đường dẫn điều hướng'}).getByRole('link')).toHaveAttribute('href','/staff/queue');
 const status = page.locator('.staff-review-status');
 await expect(status).toHaveText(/Trạng thái:\s*Mới/);
 await expect(status).toHaveCSS('display','flex');
 await expect(page.getByRole('heading',{name:'Không tiếp nhận yêu cầu',exact:true})).toHaveCount(0);
 const actions = page.locator('.staff-review-actions');
 const rejectButton = actions.getByRole('button',{name:'Không tiếp nhận',exact:true});
 const formBox = (await actions.locator('form').boundingBox())!;
 const buttonBox = (await rejectButton.boundingBox())!;
 expect(buttonBox.y).toBeGreaterThan(formBox.y + formBox.height);
 expect(Math.abs(buttonBox.x + buttonBox.width - formBox.x - formBox.width)).toBeLessThan(1);
  expect(buttonBox.width).toBeCloseTo(formBox.width, 0);
 await rejectButton.click();
 const reject=page.getByRole('dialog',{name:'Xác nhận không tiếp nhận'});
 await reject.getByLabel('Lý do không tiếp nhận').fill('  ');
 await reject.getByRole('button',{name:'Xác nhận không tiếp nhận'}).click();
 await expect(reject.getByRole('alert')).toContainText('Vui lòng nhập lý do');
 await reject.getByRole('button',{name:'Hủy',exact:true}).click();
 await page.getByLabel('Tiêu đề phiếu hỗ trợ').fill('Bản nháp');
 await page.getByRole('button',{name:'Dùng thông tin khách gửi'}).click();
 await page.getByRole('button',{name:'Thay nội dung'}).click();
 await expect(page.getByLabel('Tiêu đề phiếu hỗ trợ')).toHaveValue(original.title);
 const submit=page.getByRole('button',{name:'Lập phiếu hỗ trợ',exact:true});
 await submit.click();
 await expect(page.getByRole('alert')).toContainText('Chọn mức ưu tiên');
 expect(approval).toBeUndefined();
 await page.getByRole('combobox',{name:'Mức độ ưu tiên'}).selectOption('2');
 await page.getByLabel('Tiêu đề phiếu hỗ trợ').fill('Sofa chuẩn hóa');
 await submit.click();
 await expect(page).toHaveURL('/staff/tickets/1000');
 await expect(page.getByRole('status').filter({hasText:'Đã lập phiếu hỗ trợ thành công'})).toBeVisible();
 expect(approval).toMatchObject({title:'Sofa chuẩn hóa',priority_id:'2',expected_updated_at:original.updated_at});
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
 await page.goto('/staff/team');
 await expect(page).toHaveURL('/staff/mine');
 await expect(page.getByRole('button',{name:'Lọc phiếu',exact:true})).toBeVisible();
});

for(const role of ['customer','manager'] as const)test(`${role}: staff styles do not recolor other dashboards`,async({page},info)=>{
 await fixtures(page,role);await page.goto('/'+role);await expect(page.getByRole('heading',{name:'Thông tin tài khoản',exact:true})).toBeVisible();await expect(page.locator('.staff-dashboard,.staff-stat,.staff-ticket-scroll')).toHaveCount(0);
 for(const theme of ['light','dark']){await page.getByRole('combobox',{name:'Giao diện',exact:true}).selectOption(theme);const bg=await page.locator(role==='manager'?'.manager-chart':'.stat-grid .panel').first().evaluate(e=>getComputedStyle(e).backgroundColor);expect(bg).toBe(theme==='light'?'rgb(255, 255, 255)':'rgb(21, 40, 45)');expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy()}
 if(info.project.name==='desktop'&&role==='manager')expect((await page.locator('.manager-stats').evaluate(e=>getComputedStyle(e).gridTemplateColumns)).split(' ')).toHaveLength(4);
 if(role==='customer')await expect(page.getByRole('button',{name:'Mở trợ lý AI Helpdesk',exact:true})).toBeVisible();
});

for(const total of [0,6,12])test(`mine pagination: ${total} tickets, backend pages of five and preserved filters`,async({page})=>{
 const {calls}=await fixtures(page,'staff',{mineTotal:total});await page.goto('/staff/mine');await expect(page.locator('.staff-pagination')).toContainText(`${total} phiếu`);
 const next=page.locator('.staff-pagination').getByRole('button',{name:'Sau',exact:true});const previous=page.locator('.staff-pagination').getByRole('button',{name:'Trước',exact:true});await expect(previous).toBeDisabled();
 const seen:string[]=[];const pages=Math.max(1,Math.ceil(total/5));
 for(let p=1;p<=pages;p++){
  await expect(page.locator('.ticket-table tbody tr')).toHaveCount(Math.max(0,Math.min(5,total-(p-1)*5)));await expect(page.locator('.staff-pagination')).toContainText(`Trang ${p}`);await expect(page.locator('.staff-pagination-details>span')).toHaveText(`Trang ${p} / ${pages}`);await expect(page.locator('.staff-pagination-details small')).toHaveText(`Hiển thị ${total?(p-1)*5+1:0}–${Math.min(p*5,total)} trên tổng ${total} phiếu`);
  seen.push(...await page.locator('.ticket-table tbody tr td:first-child>a').allTextContents());
  if(p<pages){await expect(next).toBeEnabled();await next.click()}else await expect(next).toBeDisabled();
 }
 expect(seen.length).toBe(total);expect(new Set(seen).size).toBe(total);
 if(!total)await expect(page.getByText('Chưa có phiếu phù hợp.',{exact:false})).toBeVisible();
 if(total>5){
  await page.getByLabel('Mã hoặc tiêu đề').fill('Sofa');await page.getByRole('button',{name:'Lọc phiếu',exact:true}).click();await expect(page.locator('.staff-pagination')).toContainText('Trang 1');await expect(page.locator('.ticket-table tbody tr').first()).toContainText('Sofa');
  await next.click();await expect(page.locator('.staff-pagination')).toContainText('Trang 2');await expect(page.locator('.ticket-table tbody tr').first()).toContainText('Sofa');
  const last=calls.filter(c=>c.url.pathname==='/api/v1/staff/tickets').at(-1)!.url.searchParams;expect(last.get('page_size')).toBe('5');expect(last.get('search')).toBe('Sofa');expect(last.get('page')).toBe('2');
  await previous.click();await expect(page.locator('.staff-pagination')).toContainText('Trang 1');
 }
});

test('mine footer recomputes total, pages and range from filtered API response',async({page})=>{
 await fixtures(page);
 await page.route('**/api/v1/staff/tickets?**',async route=>{
  const url=new URL(route.request().url());const filtered=!!url.searchParams.get('search');const total=filtered?2:6;const p=Number(url.searchParams.get('page')||1);const size=Number(url.searchParams.get('page_size')||10);
  await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({items:Array.from({length:Math.max(0,Math.min(size,total-(p-1)*size))},(_,i)=>ticket(i+(p-1)*size,'mine',filtered?'Lọc':'')),page:p,page_size:size,total})});
 });
 await page.goto('/staff/mine');await expect(page.locator('.staff-pagination-details>span')).toHaveText('Trang 1 / 2');await expect(page.locator('.staff-pagination-details small')).toHaveText('Hiển thị 1–5 trên tổng 6 phiếu');
 await page.locator('.staff-pagination').getByRole('button',{name:'Sau',exact:true}).click();await expect(page.locator('.staff-pagination-details>span')).toHaveText('Trang 2 / 2');await expect(page.locator('.staff-pagination-details small')).toHaveText('Hiển thị 6–6 trên tổng 6 phiếu');
 await page.getByLabel('Mã hoặc tiêu đề').fill('Lọc');await page.getByRole('button',{name:'Lọc phiếu',exact:true}).click();await expect(page.locator('.staff-pagination-details>span')).toHaveText('Trang 1 / 1');await expect(page.locator('.staff-pagination-details small')).toHaveText('Hiển thị 1–2 trên tổng 2 phiếu');await expect(page.locator('.staff-pagination').getByRole('button',{name:'Sau',exact:true})).toBeDisabled();
 for(const theme of ['dark','light']){await page.getByRole('combobox',{name:'Giao diện',exact:true}).selectOption(theme);await expect(page.locator('.staff-mine-panel .staff-pagination-details')).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy()}
});

for(const theme of ['light','dark'])test(`new ticket form: equal panels, lookup/required/error preservation/double-submit · ${theme}`,async({page},info)=>{
 await page.addInitScript(mode=>localStorage.setItem('helpdesk-theme',mode),theme);const {calls,failCreateOnce}=await fixtures(page);await page.goto('/staff/new');
 const submit=page.getByRole('button',{name:'Lập phiếu mới',exact:true});await expect(submit).toBeDisabled();
 const search=page.getByLabel('Tìm khách hàng theo họ tên, email đầy đủ hoặc ID');await search.fill('empty');await search.press('Enter');await expect(page.getByText('Không tìm thấy khách hàng hoạt động phù hợp.',{exact:false})).toBeVisible();await expect(submit).toBeDisabled();
 for(const query of ['Khách','customer@example.invalid','111']){await search.fill(query);await search.press('Enter');await expect(page.getByText('Tìm thấy 1 kết quả',{exact:false})).toBeVisible();expect(calls.filter(c=>c.url.pathname.endsWith('/customers')).at(-1)!.url.searchParams.get('search')).toBe(query)}
 await page.getByRole('combobox',{name:'Khách hàng',exact:true}).selectOption('111');await submit.click();expect(calls.filter(c=>c.method==='POST'&&c.url.pathname==='/api/v1/staff/tickets')).toHaveLength(0);
 await page.getByLabel('Tiêu đề',{exact:true}).fill('   ');await page.getByRole('combobox',{name:'Loại hỗ trợ',exact:true}).selectOption('6');await page.getByRole('combobox',{name:'Mức ưu tiên',exact:true}).selectOption('2');await page.getByLabel('Mô tả chi tiết',{exact:true}).fill('Khách gọi điện yêu cầu kiểm tra sofa.');await submit.click();await expect(page.getByRole('alert')).toContainText('không được để trống');
 await page.getByLabel('Tiêu đề',{exact:true}).fill('Bảo hành sofa qua điện thoại');
 const top=(await page.locator('.staff-new-search').boundingBox())!;const bottom=(await page.locator('.staff-new-form').boundingBox())!;expect(Math.abs(top.x-bottom.x)).toBeLessThan(1);expect(Math.abs(top.width-bottom.width)).toBeLessThan(1);
 const kind=(await page.locator('#staff-new-type').boundingBox())!;const priority=(await page.locator('#staff-new-priority').boundingBox())!;if(info.project.name==='mobile'){expect(Math.abs(kind.x-priority.x)).toBeLessThan(1);expect(priority.y).toBeGreaterThan(kind.y)}else{expect(Math.abs(kind.y-priority.y)).toBeLessThan(1);expect(priority.x).toBeGreaterThan(kind.x+50)};expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:`test-results/staff-new-${theme}-${info.project.name}.png`,fullPage:true});
 failCreateOnce();await submit.click();await expect(page.getByRole('alert')).toContainText('Dữ liệu đã nhập được giữ lại');await expect(page.getByLabel('Tiêu đề',{exact:true})).toHaveValue('Bảo hành sofa qua điện thoại');await expect(page.getByRole('combobox',{name:'Khách hàng',exact:true})).toHaveValue('111');
 await page.locator('.staff-new-form').evaluate(e=>{const form=e as HTMLFormElement;form.requestSubmit();form.requestSubmit()});await expect(page.getByRole('status')).toContainText('Đã lập phiếu mới thay khách hàng');await expect(page.getByRole('link',{name:'Xem phiếu vừa lập',exact:true})).toHaveAttribute('href','/staff/tickets/9001');
 const posted=calls.filter(c=>c.method==='POST'&&c.url.pathname==='/api/v1/staff/tickets');expect(posted).toHaveLength(2);expect(posted[1].body).toMatchObject({customer_id:'111',type_id:'6',priority_id:'2',title:'Bảo hành sofa qua điện thoại'});expect(posted[1].csrf).toBe('ui-fixture-only-csrf');expect(JSON.stringify(posted[1].body)).not.toContain('assigned');
});

test('new ticket upload errors keep receipt and unavailable detail link is hidden',async({page})=>{
 const {calls}=await fixtures(page,'staff',{denyView:true,uploadError:true});await page.goto('/staff/new');await page.getByLabel('Tìm khách hàng theo họ tên, email đầy đủ hoặc ID').fill('111');await page.getByRole('button',{name:'Tìm khách hàng',exact:true}).click();await page.getByRole('combobox',{name:'Khách hàng',exact:true}).selectOption('111');await page.getByLabel('Tiêu đề',{exact:true}).fill('Ghi nhận sofa');await page.getByLabel('Mô tả chi tiết',{exact:true}).fill('Khách liên hệ trực tiếp.');await page.getByRole('combobox',{name:'Loại hỗ trợ',exact:true}).selectOption('6');await page.getByRole('combobox',{name:'Mức ưu tiên',exact:true}).selectOption('2');
 await page.locator('#staff-new-file').setInputFiles({name:'too-big.txt',mimeType:'text/plain',buffer:Buffer.alloc(5242881)});await page.getByRole('button',{name:'Lập phiếu mới',exact:true}).click();await expect(page.getByRole('alert')).toContainText('vượt giới hạn');expect(calls.filter(c=>c.method==='POST'&&c.url.pathname==='/api/v1/staff/tickets')).toHaveLength(0);
 await page.locator('#staff-new-file').setInputFiles({name:'fixture.txt',mimeType:'text/plain',buffer:Buffer.from('Fixture only')});await page.getByRole('button',{name:'Lập phiếu mới',exact:true}).click();await expect(page.getByRole('status')).toContainText('#HT-9001');await expect(page.getByRole('alert')).toContainText('Phiếu đã tạo, tệp chưa tải lên');await expect(page.getByRole('link',{name:'Xem phiếu vừa lập',exact:true})).toHaveCount(0);expect(calls.filter(c=>c.method==='POST'&&c.url.pathname==='/api/v1/staff/tickets')).toHaveLength(1);
});

test('staff mine panel reserves five rows on desktop and grows for long titles', async ({ page }, testInfo) => {
  await fixtures(page, 'staff', { mineTotal: 7 });
  await page.route('**/api/v1/staff/tickets?*', async route => {
    const current = Number(new URL(route.request().url()).searchParams.get('page'));
    const items = current === 1
      ? Array.from({ length: 5 }, (_, i) => ticket(i, 'mine'))
      : current === 2 ? [ticket(5, 'mine')] : [{ ...ticket(6, 'mine'), title: 'Tiêu đề rất dài '.repeat(13) }];
    await route.fulfill({ json: { items, total: current === 2 ? 6 : 7, page: current, page_size: 5 } });
  });
  await page.goto('/staff/mine');
  const panel = page.locator('.staff-mine-panel');
  const rows = panel.locator('tbody tr');
  await expect(rows).toHaveCount(5);
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  const fullHeight = (await panel.boundingBox())!.height;
  await panel.getByRole('button', { name: 'Sau', exact: true }).click();
  await expect(rows).toHaveCount(1);
  const shortHeight = (await panel.boundingBox())!.height;
  if (testInfo.project.name === 'desktop') expect(Math.abs(fullHeight - shortHeight)).toBeLessThanOrEqual(1);
  else expect(shortHeight).toBeLessThan(fullHeight);
  await page.route('**/api/v1/staff/tickets?*', route => route.fulfill({ json: {
    items: Array.from({ length: 5 }, (_, i) => ({ ...ticket(i, 'mine'), title: 'Tiêu đề rất dài '.repeat(13) })),
    total: 5, page: 1, page_size: 5,
  } }));
  await panel.getByRole('button', { name: 'Trước', exact: true }).click();
  await expect(rows).toHaveCount(5);
  await expect.poll(async () => (await panel.boundingBox())!.height).toBeGreaterThan(fullHeight);
  expect(await panel.locator('.staff-ticket-scroll').evaluate(el => el.scrollHeight - el.clientHeight)).toBeLessThanOrEqual(1);
});

test('customer overview and history use server pages, preserve filters and keep links working', async ({ page }, testInfo) => {
  await fixtures(page, 'customer');
  const calls: URLSearchParams[] = [];
  const session = { id: '1', ticket_id: '1000', created_at: ticket(0, 'mine').created_at };
  await page.route('**/api/v1/customer/**', async route => {
    const url = new URL(route.request().url());
    const path = url.pathname.replace('/api/v1/customer', '');
    const params = url.searchParams;
    if (path === '/tickets' && route.request().method() === 'POST') return route.fulfill({ json: ticket(0, 'customer') });
    if (path === '/tickets') {
      calls.push(params);
      const size = Number(params.get('page_size') || 10);
      const current = Number(params.get('page') || 1);
      const total = params.get('search') === 'Trống' ? 0 : params.get('search') === '12 phiếu' ? 12 :
        params.has('type') ? 6 : params.get('search') === 'Ít phiếu' ? 2 : params.has('page') ? 6 : 30;
      const count = Math.max(0, Math.min(size, total - (current - 1) * size));
      return route.fulfill({ json: { items: Array.from({ length: count }, (_, i) =>
        ticket(i + (current - 1) * size, 'customer')), total, page: current, page_size: size } });
    }
    if (path === '/overview') return route.fulfill({ json: { total: 30, active: 10, resolved: 10, closed: 10 } });
    if (path === '/ticket-types') return route.fulfill({ json: [{ id: '6', name: 'Bảo hành sản phẩm' }] });
    if (path === '/ticket-statuses') return route.fulfill({ json: statuses.map((code, i) => ({ id: String(i + 1), code, name: labels[i] })) });
    if (path === '/attachment-policy') return route.fulfill({ json: { max_bytes: 5242880, extensions: ['.txt'] } });
    if (path === '/tickets/1000') return route.fulfill({ json: { ...ticket(0, 'customer'), history: [], attachments: [], rating: null } });
    if (path === '/tickets/1000/conversation') return route.fulfill({ json: { messages: [], attachments: [], events: [], has_older: false } });
    if (path === '/chatbot/sessions') return route.fulfill({ json: { items: [session], total: 1, page: 1 } });
    if (path === '/chatbot/sessions/1') return route.fulfill({ json: { session, messages: [], has_older: false } });
    return route.fallback();
  });
  await page.goto('/customer');
  const sidebar = page.getByRole('navigation', { name: 'Không gian Khách hàng' });
  await expect(sidebar.getByRole('link')).toHaveText(['Tổng quan', 'Tạo phiếu yêu cầu', 'Lịch sử yêu cầu']);
  await expect(page.locator('.ticket-table tbody tr')).toHaveCount(5);
  await expect(page.getByRole('button', { name: /^Thông tin cá nhân của / })).toBeVisible();
  await expect(page.getByRole('navigation', { name: 'Chuyển trang danh sách phiếu' })).toHaveCount(0);
  expect(calls.at(-1)?.get('page_size')).toBe('5');
  await page.getByRole('link', { name: /Xem tất cả/ }).click();
  await expect(page.getByRole('heading', { name: 'Lịch sử yêu cầu' })).toBeVisible();

  await page.goto('/customer/tickets?history=1&type=6&page=1');
  const panel = page.locator('.customer-history-panel');
  const rows = panel.locator('tbody tr');
  const pagination = panel.getByRole('navigation');
  await expect(rows).toHaveCount(5);
  await expect(page.getByLabel('Loại hỗ trợ')).toHaveValue('6');
  await expect(sidebar.getByRole('link', { name: 'Lịch sử yêu cầu' })).toHaveAttribute('aria-current', 'page');
  await expect(pagination).toContainText('Trang 1 / 2');
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 6 phiếu');
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  const fullHeight = (await panel.boundingBox())!.height;
  await pagination.getByRole('button', { name: 'Sau', exact: true }).click();
  await expect(rows).toHaveCount(1);
  await expect(pagination).toContainText('Trang 2 / 2');
  await expect(pagination).toContainText('Hiển thị 6–6 trên tổng 6 phiếu');
  expect(calls.at(-1)?.get('type')).toBe('6');
  expect(calls.at(-1)?.has('history')).toBe(false);
  const shortHeight = (await panel.boundingBox())!.height;
  if (testInfo.project.name === 'desktop') expect(Math.abs(fullHeight - shortHeight)).toBeLessThanOrEqual(1);
  else expect(shortHeight).toBeLessThan(fullHeight);
  for (const theme of ['dark', 'light']) {
    await page.getByRole('combobox', { name: 'Giao diện' }).selectOption(theme);
    await expect(pagination).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(await page.evaluate(() => innerWidth));
  }
  await page.getByRole('button', { name: 'Xóa lọc' }).click();
  await expect(page.getByLabel('Loại hỗ trợ')).toHaveValue('');
  await page.getByLabel('Tiêu đề phiếu').fill('12 phiếu');
  await page.getByRole('button', { name: 'Áp dụng' }).click();
  await expect(pagination).toContainText('Trang 1 / 3');
  await expect(rows).toHaveCount(5);
  await pagination.getByRole('button', { name: 'Sau', exact: true }).click();
  await expect(pagination).toContainText('Trang 2 / 3');
  await expect(rows).toHaveCount(5);
  await pagination.getByRole('button', { name: 'Sau', exact: true }).click();
  await expect(pagination).toContainText('Hiển thị 11–12 trên tổng 12 phiếu');
  await expect(rows).toHaveCount(2);
  expect(calls.at(-1)?.get('search')).toBe('12 phiếu');

  await page.goto('/customer/tickets?search=%C3%8Dt+phi%E1%BA%BFu&page=8');
  await expect(pagination).toContainText('Hiển thị 1–2 trên tổng 2 phiếu');
  await expect(page).toHaveURL(/page=1$/);
  await page.getByLabel('Tiêu đề phiếu').fill('Trống');
  await page.getByRole('button', { name: 'Áp dụng' }).click();
  await expect(page.getByText('Chưa có phiếu phù hợp')).toBeVisible();
  await expect(pagination).toContainText('Hiển thị 0 trên tổng 0 phiếu');
  await expect(pagination.getByRole('button', { name: 'Sau' })).toBeDisabled();

  await sidebar.getByRole('link', { name: 'Tạo phiếu yêu cầu' }).click();
  await expect(sidebar.locator('[aria-current=page]')).toHaveText('Tạo phiếu yêu cầu');
  await page.getByLabel('Tiêu đề', { exact: true }).fill('Kiểm tra điều hướng');
  await page.getByLabel('Loại hỗ trợ').selectOption('6');
  await page.getByLabel('Mô tả chi tiết').fill('Nội dung thử bằng fixture');
  await page.getByRole('button', { name: 'Gửi yêu cầu hỗ trợ' }).click();
  await page.getByRole('dialog', { name: 'Đã gửi yêu cầu hỗ trợ thành công!' })
    .getByRole('button', { name: 'Xem lịch sử yêu cầu' }).click();
  await expect(page.getByRole('heading', { name: 'Lịch sử yêu cầu' })).toBeVisible();
  await page.getByRole('button', { name: 'Mở trợ lý AI Helpdesk' }).click();
  await page.getByRole('link', { name: 'Xem chi tiết phiếu' }).click();
  await expect(page).toHaveURL(/\/customer\/tickets\/1000$/);
});

test('manager account and group pagination, filters and stale status confirmation', async ({ page }, testInfo) => {
  await fixtures(page, 'manager');
  const version = '2026-11-05T10:00:00.000001Z';
  const accounts = Array.from({ length: 13 }, (_, index) => ({
    id: String(100 + index), name: `Tài khoản ${index + 1}`, email: `staff-${index + 1}@example.invalid`,
    role: index < 6 ? 'NHAN_VIEN' : 'KHACH_HANG', role_label: index < 6 ? 'Nhân viên hỗ trợ' : 'Khách hàng',
    phone: null, status: 'HOAT_DONG', updated_at: version,
  }));
  const requests: URLSearchParams[] = [];
  const patches: Record<string, string>[] = [];
  await page.route(/\/api\/v1\/manager\/users(?:\/105|\?|$)/, async route => {
    const req = route.request();
    const url = new URL(req.url());
    if (url.pathname.endsWith('/105')) {
      const target = accounts[5];
      if (req.method() === 'GET') return route.fulfill({ json: target });
      const body = req.postDataJSON();
      patches.push(body);
      if (patches.length === 1) {
        target.updated_at = '2026-11-05T10:00:00.000002Z';
        target.name = 'Tài khoản 6 đã đổi tên';
        return route.fulfill({ status: 409, json: { detail: 'Dữ liệu đã thay đổi.' } });
      }
      await new Promise(resolve => setTimeout(resolve, 250));
      target.status = body.status;
      return route.fulfill({ json: target });
    }
    const params = url.searchParams;
    requests.push(params);
    const pageIndex = Number(params.get('page'));
    const size = Number(params.get('page_size'));
    const items = accounts.filter(account =>
      (!params.get('search') || account.name.includes(params.get('search')!)) &&
      (!params.get('role') || account.role === params.get('role')) &&
      (!params.get('status') || account.status === params.get('status')));
    return route.fulfill({ json: { items: items.slice((pageIndex - 1) * size, pageIndex * size), total: items.length, page: pageIndex, page_size: size } });
  });
  await page.route('**/api/v1/manager/groups?*', async route => {
    const current = Number(new URL(route.request().url()).searchParams.get('page'));
    await route.fulfill({ json: {
      items: Array.from({ length: current === 1 ? 20 : 1 }, (_, i) => ({
        id: String(i + current * 20), name: `Nhóm ${i + 1}`, description: null, members: 0, pending: 0, active: true,
      })), total: 21, page: current, page_size: 20,
    } });
  });

  await page.goto('/manager/users');
  const panel = page.getByRole('region', { name: 'Danh sách tài khoản' });
  const pagination = panel.getByRole('navigation');
  const rows = panel.locator('tbody tr');
  const next = pagination.getByRole('button', { name: 'Sau' });
  const previous = pagination.getByRole('button', { name: 'Trước' });
  await expect(rows).toHaveCount(5);
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 13 tài khoản');
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  const full = (await panel.boundingBox())!.height;
  await next.click();
  await expect(pagination).toContainText('Trang 2 / 3');
  await expect(rows).toHaveCount(5);
  await next.click();
  await expect(pagination).toContainText('Hiển thị 11–13 trên tổng 13 tài khoản');
  await expect(rows).toHaveCount(3);
  await expect(next).toBeDisabled();
  if (testInfo.project.name === 'desktop') {
    expect(Math.abs((await panel.boundingBox())!.height - full)).toBeLessThanOrEqual(1);
    const filter = page.locator('.manager-users-filter');
    const bottoms = await filter.locator('input, select, button').evaluateAll(fields => fields.map(field => field.getBoundingClientRect().bottom));
    expect(Math.max(...bottoms) - Math.min(...bottoms)).toBeLessThanOrEqual(1);
  }
  await page.getByLabel('Tên, email hoặc ID').fill('Tài khoản');
  await page.getByRole('combobox', { name: 'Vai trò', exact: true }).selectOption('NHAN_VIEN');
  await page.getByLabel('Trạng thái tài khoản').selectOption('HOAT_DONG');
  await page.getByRole('button', { name: 'Lọc tài khoản' }).click();
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 6 tài khoản');
  await next.click();
  await expect(rows).toHaveCount(1);
  await expect(pagination).toContainText('Hiển thị 6–6 trên tổng 6 tài khoản');
  expect(Object.fromEntries(requests.at(-1)!)).toMatchObject({ page: '2', page_size: '5', search: 'Tài khoản', role: 'NHAN_VIEN', status: 'HOAT_DONG' });

  for (const theme of ['dark', 'light']) {
    await page.getByRole('combobox', { name: 'Giao diện' }).selectOption(theme);
    await rows.getByRole('button', { name: /^Khóa tài khoản/ }).click();
    await expect(page.getByRole('dialog')).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(await page.evaluate(() => innerWidth));
    await page.getByRole('dialog').getByRole('button', { name: 'Hủy' }).click();
  }
  expect(patches).toHaveLength(0);
  await rows.getByRole('button', { name: /^Khóa tài khoản/ }).click();
  const dialog = page.getByRole('dialog');
  const confirm = dialog.getByRole('button', { name: 'Xác nhận khóa' });
  await dialog.getByLabel('Lý do khóa tài khoản').fill('  ');
  await confirm.click();
  await expect(dialog.getByRole('alert')).toHaveText('Vui lòng nhập lý do khóa tài khoản.');
  await dialog.getByLabel('Lý do khóa tài khoản').fill('Kiểm tra thông tin');
  await confirm.click();
  await expect(dialog.getByRole('alert')).toHaveText('Dữ liệu đã thay đổi.');
  await expect(dialog.getByText('Tài khoản 6 đã đổi tên', { exact: true })).toBeVisible();
  await confirm.evaluate(button => { (button as HTMLButtonElement).click(); (button as HTMLButtonElement).click(); });
  await expect(dialog).toHaveCount(0);
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 5 tài khoản');
  await expect(previous).toBeDisabled();
  expect(patches).toEqual([
    { name: 'Tài khoản 6', phone: null, status: 'KHOA', expected_updated_at: version, lock_reason: 'Kiểm tra thông tin' },
    { name: 'Tài khoản 6 đã đổi tên', phone: null, status: 'KHOA', expected_updated_at: accounts[5].updated_at, lock_reason: 'Kiểm tra thông tin' },
  ]);
  await page.getByLabel('Tên, email hoặc ID').fill('Không có kết quả');
  await page.getByRole('button', { name: 'Lọc tài khoản' }).click();
  await expect(panel.getByText('Không có tài khoản phù hợp.')).toBeVisible();
  await expect(pagination).toContainText('Hiển thị 0 trên tổng 0 tài khoản');

  await page.goto('/manager/groups');
  const groups = page.getByRole('region', { name: 'Danh sách nhóm hỗ trợ' });
  const groupPages = groups.getByRole('navigation');
  await expect(groupPages).toContainText('Hiển thị 1–20 trên tổng 21 nhóm');
  await groupPages.getByRole('button', { name: 'Sau' }).click();
  await expect(groups.locator('tbody tr')).toHaveCount(1);
  await expect(groupPages).toContainText('Trang 2 / 2');
  await expect(groupPages).toContainText('Hiển thị 21–21 trên tổng 21 nhóm');
});

test('manager resolves duplicate group membership with explicit confirmation', async ({ page }) => {
  await fixtures(page,'manager');
  const groups=[{id:'1',name:'Nhóm A',active:true,members:1,pending:2},
    {id:'2',name:'Nhóm B',active:true,members:1,pending:0}];
  let payload:unknown;
  await page.route('**/api/v1/manager/groups?*',route=>route.fulfill({json:{items:groups,total:2,page:1,page_size:20}}));
  await page.route('**/api/v1/manager/groups/1',route=>route.fulfill({json:{...groups[0],types:[],
    people:[{id:'77',name:'Nhân viên thử',status:'HOAT_DONG',workload:2,memberships:payload?[groups[0]]:groups}],
  }}));
  await page.route('**/api/v1/manager/groups/1/members/move',async route=>{
    payload=route.request().postDataJSON();
    await route.fulfill({json:{message:'Đã cập nhật nhóm duy nhất của nhân viên.'}});
  });
  await page.goto('/manager/groups');
  await page.getByRole('row').filter({hasText:'Nhóm A'}).getByRole('button',{name:/Chỉnh sửa/}).click();
  await expect(page.getByText('Đang thuộc 2 nhóm')).toBeVisible();
  await page.getByRole('button',{name:'Chuyển nhóm',exact:true}).click();
  const dialog=page.getByRole('dialog',{name:'Chuyển nhóm nhân viên'});
  await dialog.getByLabel('Nhóm duy nhất sau khi cập nhật').selectOption('2');
  await expect(dialog.getByRole('alert')).toContainText('Hãy điều phối');
  await expect(dialog.getByRole('button',{name:'Xác nhận chuyển nhóm'})).toBeDisabled();
  await dialog.getByLabel('Nhóm duy nhất sau khi cập nhật').selectOption('1');
  await expect(dialog).toContainText('Bỏ liên kết với Nhóm B');
  await dialog.getByRole('button',{name:'Xác nhận chuyển nhóm'}).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByText('Đã cập nhật nhóm duy nhất của nhân viên.')).toBeVisible();
  expect(payload).toEqual({employee_id:'77',expected_groups:['1','2']});
});

test('manager monitoring retains advanced filters and paginates five tickets', async ({ page }, testInfo) => {
  await fixtures(page, 'manager');
  const calls: URLSearchParams[] = [];
  const detail={...ticket(0,'mine'),customer:{id:'111',name:'Khách'},history:[],assignments:[]};
  await page.route('**/api/v1/manager/tickets/1000',route=>route.fulfill({json:detail}));
  await page.route('**/api/v1/manager/tickets/1000/conversation',route=>route.fulfill({json:{
    ...detail,messages:[],events:[],attachments:[],has_older:false,
  }}));
  await page.route(/\/api\/v1\/manager\/(catalog\/(types|priorities|statuses)|groups\?|tickets\?)/, async route => {
    const url = new URL(route.request().url());
    if (url.pathname.endsWith('/types')) return route.fulfill({ json: [{ id: '6', name: 'Bảo hành' }] });
    if (url.pathname.endsWith('/priorities')) return route.fulfill({ json: [{ id: '2', name: 'Trung bình' }] });
    if (url.pathname.endsWith('/statuses')) return route.fulfill({ json: statuses.map((code, i) => ({ id: String(i + 1), code, name: labels[i] })) });
    if (url.pathname.endsWith('/groups')) return route.fulfill({ json: { items: [], total: 0, page: 1, page_size: 100 } });
    const query = url.searchParams;
    calls.push(query);
    const current = Number(query.get('page'));
    const size = Number(query.get('page_size'));
    const total = query.get('search') === 'rỗng' ? 0 : query.has('priority') ? 6 : 12;
    const count = Math.max(0, Math.min(size, total - (current - 1) * size));
    return route.fulfill({ json: { items: Array.from({ length: count }, (_, i) => ({
      ...ticket(i + (current - 1) * size, 'mine'), priority_rank: i % 3 + 1,
    })), total, page: current, page_size: size } });
  });

  await page.goto('/manager/tickets');
  const panel = page.getByRole('region', { name: 'Danh sách giám sát phiếu' });
  const rows = panel.locator('tbody tr');
  const pagination = panel.getByRole('navigation');
  const next = pagination.getByRole('button', { name: 'Sau' });
  const advanced = page.getByRole('button', { name: /Bộ lọc nâng cao/ });
  const priority = page.getByRole('combobox', { name: 'Mức ưu tiên' });
  const search = page.getByLabel('Mã hoặc tiêu đề phiếu');
  await expect(priority).toBeHidden();
  await expect(rows).toHaveCount(5);
  await expect(panel.locator('thead th')).toHaveText(['Mã phiếu','Tiêu đề phiếu','Nhóm / Loại hỗ trợ','Trạng thái phiếu','Mức ưu tiên']);
  expect(new Set(await panel.locator('td[data-label="Mức ưu tiên"] .staff-status-badge')
    .evaluateAll(badges=>badges.map(badge=>getComputedStyle(badge).backgroundColor))).size).toBe(3);
  await expect(panel.locator('.staff-status-moi')).toHaveText('Mới');
  await expect(panel.locator('.staff-status-dang_xu_ly')).toHaveText('Đang xử lý');
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  const height = (await panel.boundingBox())!.height;
  await next.click();
  await expect(pagination).toContainText('Trang 2 / 3');
  await expect(rows).toHaveCount(5);
  await next.click();
  await expect(rows).toHaveCount(2);
  await expect(pagination).toContainText('Hiển thị 11–12 trên tổng 12 phiếu');
  if (testInfo.project.name === 'desktop') expect(Math.abs((await panel.boundingBox())!.height - height)).toBeLessThanOrEqual(1);

  await advanced.click();
  await priority.selectOption('2');
  await page.getByLabel('Tình trạng SLA').selectOption('overdue');
  await advanced.click();
  await expect(priority).toBeHidden();
  await page.getByRole('button', { name: 'Lọc dữ liệu' }).click();
  await expect(advanced).toContainText('2 đang áp dụng');
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 6 phiếu');
  await next.click();
  await expect(rows).toHaveCount(1);
  await expect(pagination).toContainText('Hiển thị 6–6 trên tổng 6 phiếu');
  expect(calls.at(-1)?.get('sla_state')).toBe('overdue');
  await advanced.click();
  await expect(priority).toHaveValue('2');
  await search.fill('chưa áp dụng');
  const refresh = page.getByRole('button', { name: 'Làm mới danh sách phiếu' });
  const reload = page.waitForRequest(request => request.url().includes('/api/v1/manager/tickets?'));
  await refresh.click();
  await reload;
  await expect(pagination).toContainText('Trang 2 / 2');
  expect(Object.fromEntries(calls.at(-1)!)).toEqual({ page: '2', page_size: '5', priority: '2', sla_state: 'overdue' });

  for (const theme of ['dark', 'light']) {
    await page.getByRole('combobox', { name: 'Giao diện' }).selectOption(theme);
    await expect(panel.locator('td[data-label="Trạng thái phiếu"] .staff-status-da_huy')).toHaveText('Đã hủy');
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBeTruthy();
  }
  await search.fill('rỗng');
  await page.getByRole('button', { name: 'Lọc dữ liệu' }).click();
  await expect(panel.getByText('Chưa có phiếu phù hợp.')).toBeVisible();
  await expect(next).toBeDisabled();
  await page.getByRole('button', { name: 'Xóa lọc' }).click();
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 12 phiếu');
  const firstRow=rows.first();
  const code=firstRow.getByRole('link',{name:/HT-1000/});
  await code.focus();
  await expect(firstRow).toHaveCSS('outline-style','solid');
  await code.press('Space');
  await expect(page).toHaveURL('/manager/tickets/1000');
  await page.getByRole('navigation',{name:'Đường dẫn điều hướng'}).getByRole('link',{name:'Giám sát phiếu'}).click();
  await page.locator('.manager-monitor-table tbody tr').first().locator('td').nth(1).click();
  await expect(page).toHaveURL('/manager/tickets/1000');
});

test('manager SLA table paginates and referenced policies allow only activation changes', async ({ page }) => {
  await fixtures(page, 'manager');
  const policies = Array.from({ length: 6 }, (_, i) => ({
    id: String(i + 1), name: `Chính sách ${i + 1}`, priority_id: 3, priority: 'Cao',
    response_minutes: 15, resolution_minutes: 120, active: i === 5, referenced: i === 5 ? 2 : 0,
  }));
  let empty = true;
  const writes: unknown[] = [];
  await page.route('**/api/v1/manager/catalog/priorities', route => route.fulfill({ json: [{ id: '3', name: 'Cao' }] }));
  await page.route(/\/api\/v1\/manager\/sla(?:\/6|\?|$)/, async route => {
    const request = route.request();
    if (request.method() === 'PATCH') {
      const body = request.postDataJSON();
      writes.push(body);
      policies[5].active = body.active;
      return route.fulfill({ json: policies[5] });
    }
    const query = new URL(request.url()).searchParams;
    const current = Number(query.get('page'));
    const size = Number(query.get('page_size'));
    return route.fulfill({ json: {
      items: empty ? [] : policies.slice((current - 1) * size, current * size),
      total: empty ? 0 : policies.length, page: current, page_size: size,
    } });
  });
  await page.goto('/manager/sla');
  const panel = page.getByRole('region', { name: 'Danh sách chính sách SLA' });
  await expect(panel.getByRole('heading', { name: 'Chưa có chính sách SLA' })).toBeVisible();
  await panel.getByRole('button', { name: 'Tạo chính sách đầu tiên' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Đóng', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  empty = false;
  await page.reload();
  const pagination = panel.getByRole('navigation');
  const rows = panel.locator('tbody tr');
  await expect(rows).toHaveCount(5);
  await expect(pagination).toContainText('Hiển thị 1–5 trên tổng 6 chính sách');
  await pagination.getByRole('button', { name: 'Sau' }).click();
  await expect(rows).toHaveCount(1);
  await expect(pagination).toContainText('Hiển thị 6–6 trên tổng 6 chính sách');
  await expect(rows.getByText('120 phút (2 giờ)')).toBeVisible();
  for (const theme of ['dark', 'light']) {
    await page.getByRole('combobox', { name: 'Giao diện' }).selectOption(theme);
    await rows.getByRole('button', { name: 'Chỉnh sửa Chính sách 6' }).click();
    const dialog = page.getByRole('dialog', { name: 'Chỉnh sửa chính sách SLA' });
    await expect(dialog.getByLabel('Tên chính sách')).toHaveAttribute('readonly', '');
    await expect(dialog.getByRole('combobox', { name: 'Mức ưu tiên SLA' })).toBeDisabled();
    await expect(dialog.getByText(/2 phiếu tham chiếu/)).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBeTruthy();
    await dialog.getByRole('button', { name: 'Hủy' }).click();
  }
  await rows.getByRole('button', { name: 'Chỉnh sửa Chính sách 6' }).click();
  const dialog = page.getByRole('dialog', { name: 'Chỉnh sửa chính sách SLA' });
  await dialog.getByRole('checkbox', { name: 'Chính sách đang có hiệu lực' }).uncheck();
  await dialog.getByRole('button', { name: 'Lưu chính sách' }).click();
  await expect(dialog).toHaveCount(0);
  await expect(rows.getByText('Đã tắt', { exact: true })).toBeVisible();
  await expect(pagination).toContainText('Trang 2 / 2');
  expect(writes).toEqual([{
    name: 'Chính sách 6', priority_id: 3, response_minutes: 15, resolution_minutes: 120, active: false,
    expected: { name: 'Chính sách 6', priority_id: 3, response_minutes: 15, resolution_minutes: 120, active: true },
  }]);
});

test('manager overview restores Bebo Bento with live filters and intervention paging', async ({ page }, info) => {
  await fixtures(page,'manager');
  const queries: URLSearchParams[]=[];
  const periods: string[]=[];
  await page.route('**/api/v1/manager/overview?*',async route=>{
    const preset=new URL(route.request().url()).searchParams.get('preset')!;
    periods.push(preset);
    await route.fulfill({json:{
      total:preset==='today'?7:9,period_start:'2026-11-01',period_end:'2026-11-19',
      segments:[{code:'processing',count:2},{code:'closed',count:1},{code:'waiting',count:1},{code:'overdue',count:3},
        {code:'other',count:preset==='today'?0:2}],
      workload:[{name:'Bảo hành và bảo trì',count:3},{name:'Tư vấn và đơn hàng',count:1}],
    }});
  });
  await page.route('**/api/v1/manager/tickets?*',async route=>{
    const query=new URL(route.request().url()).searchParams;queries.push(query);
    const current=Number(query.get('page'));const segment=query.get('dashboard_segment');
    const total=segment==='overdue'?3:6;
    const items=Array.from({length:Math.max(0,Math.min(5,total-(current-1)*5))},(_,i)=>({
      ...ticket(i,'mine'),status:'DANG_XU_LY',status_label:'Đang xử lý',sla_state:'Quá hạn',priority_rank:3,
    }));
    await route.fulfill({json:{items,total,page:current,page_size:5,segment}});
  });
  await page.route('**/api/v1/manager/reports/analytics?*',route=>route.fulfill({json:{metrics:{
    resolution_on_time:2,resolution_late:1,response_avg:40,response_samples:3,rating_avg:null,ratings:0,
  }}}));
  await page.goto('/manager');
  await expect(page.locator('.furni-split-card')).toBeVisible();
  await expect(page.locator('.furni-mini-widget')).toHaveCount(3);
  await expect(page.locator('.furni-team-bars')).toContainText('Bảo hành và bảo trì');
  await expect(page.locator('.furni-mini-widget').first()).toContainText('66,7%');
  await expect(page.locator('.furni-mini-widget').nth(1)).toContainText('40 phút');
  await expect(page.locator('.furni-mini-widget').nth(2)).toContainText('Chưa có dữ liệu');
  await expect(page.locator('.furni-table tbody tr')).toHaveCount(5);
  expect(queries.at(-1)?.get('dashboard_segment')).toBe('attention');
  await page.locator('.furni-table-card').getByRole('button',{name:'Sau',exact:true}).click();
  await expect(page.locator('.furni-table tbody tr')).toHaveCount(1);
  const donut=page.getByRole('button',{name:'Lọc Quá hạn SLA',exact:true});
  await donut.focus();await donut.press('Enter');
  await expect.poll(()=>queries.at(-1)?.get('dashboard_segment')).toBe('overdue');
  expect(queries.at(-1)?.get('page')).toBe('1');
  await page.getByRole('button',{name:'7 ngày qua',exact:true}).click();
  await expect.poll(()=>periods.at(-1)).toBe('7d');
  await page.getByRole('button',{name:'Tháng này',exact:true}).click();
  await expect.poll(()=>periods.at(-1)).toBe('month');
  await expect(page.locator('.furni-donut-hub-interactive .furni-hub-number')).toHaveText('9');
  await expect(page.getByText(/Đóng các phiếu|Gán thợ|Còn 25p|Còn 4h|KTV Tuấn|Vinhomes/)).toHaveCount(0);
  for (const theme of ['dark','light']) {
    await page.getByRole('combobox',{name:'Giao diện'}).selectOption(theme);
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
    await page.evaluate(() => { (document.activeElement as HTMLElement)?.blur(); scrollTo(0,0); });
    await page.screenshot({path:`test-results/bebo-overview-${info.project.name}-${theme}.png`,fullPage:true});
  }
});

test('manager report activity pages keep the applied date and scope', async ({ page }, info) => {
  await fixtures(page, 'manager');
  const requests: URLSearchParams[] = [];
  const analyticsRequests: URLSearchParams[] = [];
  await page.route(/\/api\/v1\/manager\/(reports\/(analytics|activity)\?|groups\?|catalog\/types)/, async route => {
    const url = new URL(route.request().url());
    if (url.pathname.endsWith('/groups')) return route.fulfill({ json: { items: [{ id: '2', name: 'Bảo hành' }], total: 1, page: 1, page_size: 100 } });
    if (url.pathname.endsWith('/types')) return route.fulfill({ json: [{ id: '6', name: 'Sofa' }] });
    if (url.pathname.endsWith('/analytics')) {
      analyticsRequests.push(url.searchParams);
      return route.fulfill({ json: {
      start: '2026-11-01', end: '2026-11-05', snapshot_at: '2026-11-05T12:00:00Z',
      group_id: url.searchParams.get('group'), type_id: url.searchParams.get('type'), groups: [],
      trend: [{grain:'day',date:'2026-11-05',created:2,resolved:1}], rating_distribution: [],
      metrics: {
        created: 2, resolved: 1, response_samples: 0, response_avg: null, resolution_avg: null,
        response_on_time: 0, response_late: 0, resolution_on_time: 0, resolution_late: 0,
        response_missing: 0, resolution_missing: 0, response_open_late: 0, response_open_on_time: 0,
        resolution_open_late: 0, resolution_open_on_time: 0, intake_missing_sla: 0, missing_resolution_time: 0,
        closed_in_period: 0, closed_with_rating: 0, ratings: 0, rating_avg: null, positive: 0,
      },
    } });
    }
    requests.push(url.searchParams);
    const current = Number(url.searchParams.get('page'));
    return route.fulfill({ json: {
      items: Array.from({ length: current === 1 ? 10 : 1 }, (_, i) => ({
        id: `${current}-${i}`, ticket_id: '1000', happened_at: '2026-11-05T12:00:00Z',
        kind: 'Phản hồi công khai', actor: 'Nhân viên', detail: 'Có trao đổi mới',
      })), total: 11, page: current, page_size: 10,
    } });
  });
  await page.goto('/manager/reports');
  await page.getByRole('combobox', { name: 'Nhóm hỗ trợ' }).selectOption('2');
  await page.getByRole('combobox', { name: 'Loại yêu cầu' }).selectOption('6');
  await expect(page.locator('.furni-scope-tags')).toContainText('Bảo hành');
  await expect(page.locator('.furni-scope-tags')).toContainText('Sofa');
  const history = page.getByRole('region', { name: 'Lịch sử hoạt động hỗ trợ' });
  await expect(history.locator('tbody tr')).toHaveCount(10);
  for (const theme of ['dark','light']) {
    await page.getByRole('combobox',{name:'Giao diện'}).selectOption(theme);
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
    await page.screenshot({path:`test-results/bebo-reports-${info.project.name}-${theme}.png`,fullPage:true});
  }
  await page.emulateMedia({media:'print'});
  await expect(page.locator('.sidebar')).toBeHidden();
  await expect(page.locator('.report-filters')).toBeHidden();
  await expect(page.locator('.furni-report-scope-card')).toContainText('Bảo hành');
  await expect(page.locator('.report-trend svg[role="img"]')).toBeVisible();
  await page.emulateMedia({media:'screen'});
  await history.getByLabel('Tên người thực hiện').fill('Nhân viên');
  await history.getByLabel('Tìm hoạt động').fill('#HT-1000');
  await history.getByRole('button', { name: 'Lọc hoạt động' }).click();
  await history.getByRole('button', { name: 'Phản hồi công khai', exact: true }).click();
  await expect.poll(() => requests.at(-1)?.get('kind')).toBe('public');
  await history.getByRole('button', { name: 'Sau' }).click();
  await expect(history.locator('tbody tr')).toHaveCount(1);
  await expect(history.getByRole('navigation')).toContainText('Hiển thị 11–11 trên tổng 11 hoạt động');
  expect(Object.fromEntries(requests.at(-1)!)).toEqual({
    preset: 'custom', start: '2026-11-01', end: '2026-11-05', page: '2', group: '2', type: '6',
    q: '#HT-1000', actor_name: 'Nhân viên', kind: 'public',
  });
  await page.locator('.report-filters').getByRole('button', { name: 'Đặt lại', exact: true }).click();
  await expect(history.locator('tbody tr')).toHaveCount(10);
  expect(requests.at(-1)?.get('group')).toBeNull();
  await page.getByLabel('Khoảng thời gian').selectOption('custom');
  await page.getByLabel('Từ ngày',{exact:true}).fill('2026-11-10');
  await page.getByLabel('Đến ngày',{exact:true}).fill('2026-11-01');
  await expect(page.getByRole('alert')).toContainText('ngày bắt đầu không sau ngày kết thúc');
  await expect(page.getByRole('button',{name:'Xuất bản in (PDF)'})).toBeDisabled();
  await page.getByLabel('Đến ngày',{exact:true}).fill('2026-11-12');
  await expect.poll(() => analyticsRequests.at(-1)?.get('end')).toBe('2026-11-12');
  expect(analyticsRequests.at(-1)?.get('start')).toBe('2026-11-10');
  await expect(page.getByRole('button',{name:'Xuất bản in (PDF)'})).toBeEnabled();
});

test('customer profile dialog refreshes identity and new ticket stays centered', async ({ page }) => {
  await fixtures(page, 'customer');
  const profile = { name: 'Khách hàng thử', email: 'customer@example.invalid', phone: '', gender: '' };
  let releaseSave!: () => void;
  const saveGate = new Promise<void>(resolve => { releaseSave = resolve; });
  await page.route('**/api/v1/auth/me', route => route.fulfill({ json: {
    user: { id: '77', name: profile.name, email: profile.email, role: 'customer', role_label: 'Khách hàng' },
  } }));
  await page.route('**/api/v1/customer/profile', async route => {
    if (route.request().method() === 'PATCH') {
      await saveGate;
      Object.assign(profile, route.request().postDataJSON());
    }
    await route.fulfill({ json: profile });
  });
  await page.route('**/api/v1/customer/ticket-types', route => route.fulfill({ json: [{ id: '6', name: 'Bảo hành' }] }));
  await page.route('**/api/v1/customer/attachment-policy', route => route.fulfill({ json: { max_bytes: 1024, extensions: ['.png'] } }));

  await page.goto('/customer/profile');
  await expect(page).toHaveURL('/customer');
  const dialog = page.getByRole('dialog', { name: 'Thông tin cá nhân' });
  const identity = page.getByRole('button', { name: /^Thông tin cá nhân của/ });
  await expect(dialog).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(dialog).toHaveCount(0);
  await expect(identity).toBeFocused();
  for (const theme of ['light', 'dark']) {
    await page.getByRole('combobox', { name: 'Giao diện' }).selectOption(theme);
    await identity.click();
    await expect(dialog.getByLabel('Email', { exact: true })).toHaveAttribute('readonly', '');
    expect((await dialog.boundingBox())!.width).toBeLessThanOrEqual(page.viewportSize()!.width);
    await dialog.getByRole('button', { name: theme === 'light' ? 'Đóng' : 'Hủy', exact: true }).click();
    await expect(identity).toBeFocused();
  }

  await identity.click();
  await dialog.getByLabel('Họ và tên', { exact: true }).fill('Khách đã cập nhật');
  await dialog.getByLabel('Số điện thoại (không bắt buộc)').fill('123');
  await dialog.getByRole('button', { name: 'Lưu thay đổi' }).click();
  await expect(dialog.getByRole('alert')).toContainText('Số điện thoại không hợp lệ');
  await dialog.getByLabel('Số điện thoại (không bắt buộc)').fill('0912345678');
  await dialog.getByRole('button', { name: 'Lưu thay đổi' }).click();
  try {
    await expect(dialog.getByRole('button', { name: 'Đang lưu…' })).toBeDisabled();
    await expect(dialog.getByRole('button', { name: 'Đóng' })).toBeDisabled();
    await page.keyboard.press('Escape');
    await expect(dialog).toBeVisible();
  } finally {
    releaseSave();
  }
  await expect(dialog.getByRole('status')).toHaveText('Đã cập nhật hồ sơ.');
  await dialog.getByRole('button', { name: 'Đóng' }).click();
  await expect(identity).toHaveText(/Khách đã cập nhật/);
  await page.getByRole('navigation', { name: 'Không gian Khách hàng' })
    .getByRole('link', { name: 'Tạo phiếu yêu cầu' }).click();
  const layout = page.locator('.customer-new-ticket-page');
  await expect(layout.getByRole('heading', { name: 'Tạo phiếu yêu cầu' })).toBeVisible();
  const box = (await layout.boundingBox())!;
  const parent = (await page.locator('.dashboard-main > .container').boundingBox())!;
  expect(box.width).toBeLessThanOrEqual(860);
  expect(Math.abs(box.x + box.width / 2 - parent.x - parent.width / 2)).toBeLessThanOrEqual(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBeTruthy();
});

test('customer request receipt, edit, cancel and direct summaries', async ({ page }) => {
  await fixtures(page, 'customer');
  const request = {
    ...ticket(0, 'customer'), can_modify: true, end_reason: null as string | null, closed_by_customer: false,
    assigned_to: null, messages: [], attachments: [], history: [],
    rating: null as { stars: number; comment: string | null; created_at: string } | null,
  };
  let posts = 0;
  let stale = false;
  await page.route(/\/api\/v1\/customer\/(tickets|ticket-types|ticket-statuses|attachment-policy)/, async route => {
    const req = route.request();
    const path = new URL(req.url()).pathname.replace('/api/v1/customer', '');
    if (path === '/ticket-types') return route.fulfill({ json: [{ id: request.type_id, name: request.type_name }] });
    if (path === '/ticket-statuses') return route.fulfill({ json: [] });
    if (path === '/attachment-policy') return route.fulfill({ json: { max_bytes: 1024, extensions: ['.txt'] } });
    if (path === '/tickets' && req.method() === 'POST') {
      posts++;
      Object.assign(request, req.postDataJSON());
      return route.fulfill({ status: 201, json: request });
    }
    if (path === '/tickets') return route.fulfill({ json: { items: [request], total: 1, page: 1, page_size: 5 } });
    if (path.endsWith('/attachments')) return route.fulfill({ status: 415, json: { detail: 'Tệp không hợp lệ.' } });
    if (path.endsWith('/cancel')) {
      Object.assign(request, { status: 'DA_HUY', status_label: 'Đã hủy', can_modify: false, end_reason: req.postDataJSON().reason });
      return route.fulfill({ json: request });
    }
    if (path.endsWith('/rating')) {
      request.rating = { ...req.postDataJSON(), created_at: request.created_at };
      return route.fulfill({ status: 201, json: request.rating });
    }
    if (path.endsWith('/conversation')) return route.fulfill({ json: { messages: [], attachments: [], events: [], has_older: false } });
    if (req.method() === 'PATCH') {
      if (stale) {
        Object.assign(request, { status: 'DANG_XU_LY', status_label: 'Đang xử lý', can_modify: false });
        return route.fulfill({ status: 409, json: { detail: 'Yêu cầu đã được tiếp nhận.' } });
      }
      Object.assign(request, req.postDataJSON());
    }
    return route.fulfill({ json: request });
  });
  await page.goto('/customer/tickets/new');
  await page.getByLabel('Tiêu đề', { exact: true }).fill('Yêu cầu mới');
  await page.getByRole('combobox', { name: 'Loại hỗ trợ' }).selectOption(request.type_id);
  await page.getByLabel('Mô tả chi tiết').fill('Nội dung thử');
  await page.getByLabel('Tệp đính kèm (không bắt buộc)').setInputFiles({ name: 'fixture.txt', mimeType: 'text/plain', buffer: Buffer.from('fixture') });
  await page.getByRole('button', { name: 'Gửi yêu cầu hỗ trợ' }).click();
  const receipt = page.getByRole('dialog', { name: 'Đã gửi yêu cầu hỗ trợ thành công!' });
  await expect(receipt.getByRole('alert')).toContainText('tệp chưa tải lên');
  await receipt.getByRole('button', { name: 'Xem lịch sử yêu cầu' }).click();
  await expect(page).toHaveURL('/customer/tickets');
  expect(posts).toBe(1);

  const row = page.getByRole('row').filter({ hasText: 'Yêu cầu mới' });
  await page.getByRole('combobox', { name: 'Giao diện' }).selectOption('dark');
  await row.hover();
  await expect(row).toHaveCSS('cursor', 'pointer');
  await row.getByText(request.type_name).click();
  const summary = page.getByRole('dialog', { name: 'Chi tiết yêu cầu' });
  await expect(summary.getByText('Nội dung thử')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Hội thoại hỗ trợ' })).toHaveCount(0);
  await page.keyboard.press('Escape');
  await row.getByRole('link').click();
  await summary.getByRole('button', { name: 'Chỉnh sửa' }).click();
  const edit = page.getByRole('dialog', { name: 'Chỉnh sửa yêu cầu' });
  await edit.getByLabel('Tiêu đề', { exact: true }).fill('Yêu cầu đã sửa');
  await edit.getByRole('button', { name: 'Lưu thay đổi' }).click();
  await expect(summary.getByText(/Yêu cầu đã sửa/)).toBeVisible();
  await page.keyboard.press('Escape');
  const updated = page.getByRole('row').filter({ hasText: 'Yêu cầu đã sửa' });
  await updated.getByRole('link').click();
  await summary.getByRole('button', { name: 'Hủy yêu cầu' }).click();
  const cancel = page.getByRole('dialog', { name: 'Xác nhận hủy yêu cầu' });
  await cancel.getByLabel('Lý do hủy yêu cầu').fill('  ');
  await cancel.getByRole('button', { name: 'Xác nhận hủy yêu cầu' }).click();
  await expect(cancel.getByRole('alert')).toContainText('Vui lòng nhập lý do');
  await cancel.getByLabel('Lý do hủy yêu cầu').fill('Đã tự khắc phục');
  await cancel.getByRole('button', { name: 'Xác nhận hủy yêu cầu' }).click();
  await expect(updated.getByText('Lý do: Đã tự khắc phục')).toBeVisible();
  await expect(page.getByRole('columnheader', { name: 'Thao tác' })).toHaveCount(0);

  await page.goto('/customer/tickets/1000');
  await expect(summary.getByText(/Lý do hủy:.*Đã tự khắc phục/)).toBeVisible();
  await expect(summary.getByRole('button', { name: 'Hủy yêu cầu' })).toBeDisabled();
  await expect(page.getByRole('heading', { name: 'Hội thoại hỗ trợ' })).toHaveCount(0);
  Object.assign(request, { status: 'DA_DONG', status_label: 'Đã đóng', end_reason: null, closed_by_customer: true });
  await page.reload();
  await summary.getByRole('radio', { name: '5 ★' }).check();
  await summary.getByRole('button', { name: 'Gửi đánh giá' }).click();
  await expect(summary.getByText('5/5 sao')).toBeVisible();
  await page.keyboard.press('Escape');

  Object.assign(request, { status: 'MOI', status_label: 'Mới', can_modify: true });
  stale = true;
  await page.reload();
  await updated.getByRole('link').click();
  await summary.getByRole('button', { name: 'Chỉnh sửa' }).click();
  await edit.getByRole('button', { name: 'Lưu thay đổi' }).click();
  await expect(summary.getByRole('alert')).toContainText('đã được tiếp nhận');
  await expect(summary.getByRole('button', { name: 'Chỉnh sửa' })).toBeDisabled();
  await summary.getByRole('link', { name: 'Mở chi tiết và hội thoại' }).click();
  await expect(page.getByRole('heading', { name: 'Hội thoại hỗ trợ' })).toBeVisible();
  await page.getByRole('combobox', { name: 'Giao diện' }).selectOption('light');
  for (const [status, label] of [['TAM_DUNG', 'Tạm dừng'], ['DA_GIAI_QUYET', 'Đã giải quyết']]) {
    Object.assign(request, { status, status_label: label });
    await page.reload();
    await expect(page.getByRole('heading', { name: 'Hội thoại hỗ trợ' })).toBeVisible();
    await expect(summary).toHaveCount(0);
  }
});
