import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { RefreshCw } from 'lucide-react';
import { Button } from '../components';
import { formatDate } from '../customer/api';
import { staffApi, type StaffPage } from './api';

export function StaffQueue() {
  const navigate = useNavigate();
  const [data, setData] = useState<StaffPage>();
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('newest');
  const [refresh, setRefresh] = useState(0);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    staffApi<StaffPage>(`/tickets?scope=queue&sort=${sort}&page=${page}&page_size=5`).then(result => {
      if (!active) return;
      const last = Math.max(1, Math.ceil(result.total / result.page_size));
      if (result.page > last) setPage(last);
      else { setData(result); setBusy(false); }
    }).catch(e => {
      if (active) { setError(e.message); setBusy(false); }
    });
    return () => { active = false; };
  }, [page, sort, refresh]);

  function move(next: number) {
    setBusy(true);
    setError('');
    if (page === next) setRefresh(value => value + 1);
    else setPage(next);
  }

  const pages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;
  return <>
    <div className="page-heading"><div><h1>Yêu cầu chờ tiếp nhận</h1><p>Mở yêu cầu để xem nội dung gốc và lập phiếu hỗ trợ.</p></div>
      <Button className="secondary" disabled={busy} aria-label="Làm mới hàng đợi" title="Làm mới hàng đợi"
        onClick={() => move(page)}><RefreshCw size={18} aria-hidden="true"/></Button>
    </div>
    <section className="panel staff-queue-controls">
      <div><strong>Yêu cầu đang chờ</strong><p>{data?.total ?? '—'}</p></div>
      {data?.attention != null && <div><strong>Cần chú ý</strong><p>{data.attention}</p><small>Đã quá hạn hoặc còn tối đa 60 phút.</small></div>}
      <label className="field">Sắp xếp theo<select value={sort} onChange={event => {
        setBusy(true); setError(''); setPage(1); setSort(event.target.value);
      }}><option value="newest">Mới nhất</option><option value="due">Gần đến hạn</option></select></label>
    </section>
    {error && <p className="error-box" role="alert">{error}</p>}
    {busy && <p role="status">Đang tải yêu cầu…</p>}
    {data && <section className="panel staff-ticket-panel staff-queue-panel">
      {data.items.length ? <div className="table-scroll"><table className="ticket-table staff-queue-table">
        <thead><tr>{['Yêu cầu','Loại hỗ trợ','Thời điểm gửi','Hạn tạm tính','Trạng thái'].map(label => <th key={label}>{label}</th>)}</tr></thead>
        <tbody>{data.items.map(ticket => {
          const path = `/staff/requests/${ticket.id}`;
          const due = ticket.sla_name && [ticket.first_response_at ? null : ticket.response_due, ticket.resolution_due]
            .filter((value): value is string => Boolean(value)).sort((a,b) => Date.parse(a)-Date.parse(b))[0];
          return <tr key={ticket.id} onClick={event => {
            if (event.target instanceof Element && !event.target.closest('a, button')) navigate(path);
          }}>
            <td data-label="Yêu cầu"><Link className="text-link" to={path}>#HT-{ticket.id} · {ticket.title}</Link>
              {ticket.recommended && <span className="badge staff-recommended-badge">Ưu tiên cho bạn</span>}</td>
            <td data-label="Loại hỗ trợ">{ticket.type_name ?? 'Chưa phân loại'}</td>
            <td data-label="Thời điểm gửi">{formatDate(ticket.created_at)}</td>
            <td data-label="Hạn tạm tính">{due ? <>{formatDate(due)}<small>{ticket.sla_state} · {ticket.priority} tạm tính</small></> : 'Chưa có hạn'}</td>
            <td data-label="Trạng thái"><span className="staff-status-badge staff-status-moi">{ticket.status_label}</span></td>
          </tr>;
        })}</tbody>
      </table></div> : <p className="empty-state">Hiện không có yêu cầu chờ tiếp nhận.</p>}
      <nav className="staff-pagination" aria-label="Chuyển trang hàng đợi">
        <Button className="secondary" disabled={busy || data.page <= 1} onClick={() => move(data.page - 1)}>Trước</Button>
        <span>Trang {data.page} / {pages} · {data.total} yêu cầu</span>
        <Button className="secondary" disabled={busy || data.page >= pages} onClick={() => move(data.page + 1)}>Sau</Button>
      </nav>
    </section>}
  </>;
}
