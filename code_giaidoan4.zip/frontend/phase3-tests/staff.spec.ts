import { test, expect } from '@playwright/test';
const fixtures=JSON.parse(process.env.HELPDESK_PHASE3_FIXTURES||'{}');
const password=process.env.HELPDESK_PHASE3_PASSWORD;
if(!password)throw new Error('Chạy qua scripts/test_phase3.py --execute --stage E --browser');
test('staff queue, accept same ticket, reply/internal/file, resolve; customer closes and rates; staff phone ticket',async({page},info)=>{
 const f=fixtures[info.project.name];
 async function login(email:string){await page.goto('/login');await page.getByLabel('Email',{exact:true}).fill(email);await page.getByLabel('Mật khẩu',{exact:true}).fill(password!);await page.getByRole('button',{name:'Đăng nhập',exact:true}).click();await expect(page).toHaveURL(email===f.staff_email?'/staff':'/customer')}
 async function mobile(){expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy()}
 await login(f.staff_email);await expect(page.getByRole('heading',{name:'Tổng quan hỗ trợ',exact:true})).toBeVisible();await mobile();
 await page.goto('/staff/queue');await page.getByLabel('Mã hoặc tiêu đề').fill(f.ticket_id);await page.getByRole('button',{name:'Lọc phiếu',exact:true}).click();
 await expect(page.getByRole('link',{name:`#HT-${f.ticket_id} · Bảo hành sofa`,exact:true})).toBeVisible();await page.screenshot({path:`test-results/staff-queue-${info.project.name}.png`,fullPage:true});await mobile();
 await page.getByRole('button',{name:'Tiếp nhận',exact:true}).click();await expect(page.getByText('Chưa có phiếu phù hợp.',{exact:false})).toBeVisible();
 await page.goto(`/staff/tickets/${f.ticket_id}`);await expect(page.getByRole('heading',{name:'Bảo hành sofa',exact:true})).toBeVisible();await mobile();await expect(page.getByRole('combobox',{name:'Loại hỗ trợ',exact:true})).toHaveValue(f.type_id);await expect(page.getByRole('combobox',{name:'Mức ưu tiên',exact:true})).toHaveValue('2');
 await page.getByLabel('Nội dung trao đổi').fill('Ghi chú nội bộ chỉ dành cho nhóm');await page.getByRole('checkbox',{name:'Ghi chú nội bộ (khách không nhìn thấy)'}).check();await page.getByRole('button',{name:'Gửi nội dung',exact:true}).click();await expect(page.getByText('Ghi chú nội bộ chỉ dành cho nhóm',{exact:true})).toBeVisible();
 await page.getByLabel('Nội dung trao đổi').fill('Đã sửa chân sofa, mời khách xác nhận.');await page.getByRole('button',{name:'Gửi nội dung',exact:true}).click();await expect(page.getByText('Đã sửa chân sofa, mời khách xác nhận.',{exact:true})).toBeVisible();
 await page.locator('#staff-upload').setInputFiles({name:'bien-ban.txt',mimeType:'text/plain',buffer:Buffer.from('Da kiem tra sofa')});await page.getByRole('button',{name:'Tải tệp lên',exact:true}).click();await expect(page.getByText('bien-ban.txt',{exact:true})).toBeVisible();
 await page.screenshot({path:`test-results/staff-detail-${info.project.name}.png`,fullPage:true});
 await page.getByLabel('Trạng thái tiếp theo').selectOption('DA_GIAI_QUYET');await page.getByRole('button',{name:'Cập nhật trạng thái',exact:true}).click();await expect(page.getByText('Đã giải quyết',{exact:true}).first()).toBeVisible();
 await page.getByRole('button',{name:'Đăng xuất',exact:true}).click();await expect(page).toHaveURL('/login');await login(f.customer_email);await page.goto(`/customer/tickets/${f.ticket_id}`);
 await expect(page.getByText('Đã sửa chân sofa, mời khách xác nhận.',{exact:true})).toBeVisible();await expect(page.getByText('Ghi chú nội bộ chỉ dành cho nhóm',{exact:true})).toHaveCount(0);
 await page.getByRole('button',{name:'Đóng phiếu',exact:true}).click();await page.getByRole('button',{name:'Xác nhận đóng',exact:true}).click();
 await page.getByRole('radio',{name:'5 ★',exact:true}).check();await page.getByRole('button',{name:'Gửi đánh giá',exact:true}).click();await expect(page.getByText('5/5 sao',{exact:true})).toBeVisible();
 await page.getByRole('button',{name:'Đăng xuất',exact:true}).click();await expect(page).toHaveURL('/login');await login(f.staff_email);await page.goto('/staff/new');await page.getByLabel('Tìm khách hàng theo họ tên, email đầy đủ hoặc ID').fill(f.customer_id);await page.getByRole('button',{name:'Tìm khách hàng',exact:true}).click();await page.getByRole('combobox',{name:'Khách hàng',exact:true}).selectOption(f.customer_id);await page.getByLabel('Tiêu đề',{exact:true}).fill('Khách gọi bảo hành ghế');await page.getByRole('combobox',{name:'Loại hỗ trợ',exact:true}).selectOption(f.type_id);await page.getByRole('combobox',{name:'Mức ưu tiên',exact:true}).selectOption('2');await page.getByLabel('Mô tả chi tiết').fill('Liên hệ qua điện thoại, cần kiểm tra ghế.');await mobile();await page.getByRole('button',{name:'Lập phiếu mới',exact:true}).click();await expect(page.getByRole('status')).toContainText('Đã lập phiếu mới thay khách hàng');
 expect(await page.evaluate(()=>localStorage.length)).toEqual(0);
});
