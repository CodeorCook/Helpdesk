import { Route, Routes } from 'react-router-dom';
import { ProtectedRoute, StatusPage } from './components';
import { Dashboard, SupportPlaceholder } from './pages/Dashboard';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
export function App(){return <><a className="skip-link" href="#main-content">Bỏ qua điều hướng</a><Routes><Route path="/" element={<Home/>}/><Route path="/login" element={<Login/>}/>{(['customer','staff','manager'] as const).map(role=><Route key={role} element={<ProtectedRoute role={role}/>}><Route path={`/${role}`} element={<Dashboard/>}/></Route>)}<Route element={<ProtectedRoute/>}><Route path="/support/new" element={<SupportPlaceholder/>}/><Route path="/support/lookup" element={<SupportPlaceholder/>}/></Route><Route path="*" element={<StatusPage title="404 · Không tìm thấy trang"><p>Đường dẫn này không tồn tại. Bạn có thể quay về trang chủ để tiếp tục.</p></StatusPage>}/></Routes></>;}
