from typing import Literal
from pydantic import BaseModel, Field
Role = Literal["customer", "staff", "manager"]

class LoginRequest(BaseModel):
    email: str = Field(min_length=3, max_length=254, pattern=r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
    password: str = Field(min_length=1, max_length=1024)

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    role: Role
    role_label: str

class SessionResponse(BaseModel):
    user: UserResponse
    csrf_token: str | None = None
