# Hệ thống quản lý hỗ trợ khách hàng — Giai đoạn 1

Backend FastAPI được giữ tại thư mục gốc; frontend React + Vite + TypeScript nằm trong `frontend/`.
Chỉ triển khai nền tảng xác thực và khung màn hình. Không có CRUD phiếu, SLA tự động, chatbot hoặc thống kê.

## Chạy trên Windows / VS Code

Mở thư mục dự án trong VS Code. Terminal PowerShell thứ nhất, tại thư mục gốc Backend:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
# Chỉ thực hiện nếu CHƯA có .env; giữ nguyên .env hiện có.
# Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

Không bắt buộc activate virtualenv, không cần thay ExecutionPolicy. Backend: `http://127.0.0.1:8000`, Swagger: `http://127.0.0.1:8000/docs`, health: `http://127.0.0.1:8000/health/db`.

Terminal thứ hai:

```powershell
cd frontend
npm ci
npm run dev
```

Frontend: `http://localhost:5173`. Dùng đúng hostname localhost; nếu đổi hostname/port, sửa `FRONTEND_ORIGINS` và cấu hình Vite tương ứng. Dev server proxy `/api` tới `http://127.0.0.1:8000` để cookie cùng origin với giao diện.

```powershell
npm run build
```

Node 22.12+ tương thích phiên bản Vite đã khóa trong `package-lock.json`. Frontend không chứa secret. Font Inter Variable được đóng gói cục bộ bằng `@fontsource-variable/inter`, có bộ ký tự tiếng Việt, không phụ thuộc Google Fonts khi mở trang.

## Cấu hình

`core/database.py` đọc `.env` tại thư mục gốc Backend bằng `parents[1]`, không phụ thuộc thư mục chạy. Biến môi trường của process được ưu tiên hơn `.env`.

| Biến | Ý nghĩa |
| --- | --- |
| `DB_HOST`, `DB_PORT` | Host PostgreSQL, mặc định localhost:5432 |
| `DB_NAME` | Tên database, đã kết nối xác nhận `DB_HELPDESK` |
| `DB_USER`, `DB_PASSWORD` | Tài khoản kết nối; mật khẩu bắt buộc, không fallback |
| `DB_SCHEMA` | Schema ứng dụng; SQL cung cấp dùng `helpdesk` |
| `JWT_SECRET_KEY` | Khóa ngẫu nhiên tối thiểu 32 byte; bắt buộc để tạo/đọc phiên |
| `SESSION_MINUTES` | Thời hạn cố định 1–1440 phút, mặc định 60 |
| `FRONTEND_ORIGINS` | Danh sách origin được phép, phân cách dấu phẩy, mặc định `http://localhost:5173` |
| `COOKIE_SECURE` | `false` cho HTTP localhost, `true` khi triển khai HTTPS |

Đã bổ sung `DB_SCHEMA=helpdesk` và sinh khóa ngẫu nhiên vào `.env` local nếu trước đó chưa có các khóa này, không hiển thị giá trị bí mật. `.env`, `.venv`, node_modules, build và kết quả test được Git ignore. `.env.example` chỉ chứa mẫu cấu hình.

Nếu tự cấu hình khóa, tạo bằng trình sinh ngẫu nhiên an toàn rồi điền cục bộ; không dùng mật khẩu fallback, không commit khóa. Thiếu cấu hình trả thông báo 503 an toàn; `/` và `/docs` vẫn truy cập được.

Để thử login từ Swagger, thêm origin chính xác của trang Swagger vào `FRONTEND_ORIGINS`, ví dụ `http://localhost:5173,http://127.0.0.1:8000`, rồi khởi động lại backend. Login kiểm tra Origin để chống login CSRF.

## Database và khởi tạo có kiểm soát

File tham chiếu thật: `docs/CSDL_Helpdesk.sql`. Đã đọc đủ ba sơ đồ use case và hai bản xuất Trang chủ/Đăng nhập trong `docs/references/`. Những bản xuất còn lại chỉ là tham chiếu cho giai đoạn sau.

Ngày 20/10/2026 đã xác nhận kết nối thực tới `DB_HELPDESK`. Ban đầu database chưa có bảng ứng dụng. Sau khi người dùng đồng ý, đã thực thi đúng `docs/CSDL_Helpdesk.sql` qua `scripts/initialize_database.py --execute`, tạo schema `helpdesk` với 20 bảng và các danh mục cố định. Đã đối chiếu cột/ràng buộc thực tế, khớp SQL tham chiếu. Không tạo tài khoản sử dụng mặc định. File SQL là script khởi tạo, không phải migration.

Kiểm tra chỉ đọc:

```powershell
.\.venv\Scripts\python.exe -X utf8 scripts/inspect_database.py
```

Sau khi người dùng xác nhận việc khởi tạo, có thể mở `docs/CSDL_Helpdesk.sql` trong DBeaver, chọn đúng kết nối `DB_HELPDESK` và thực thi script. Script tạo schema helpdesk, bảng, index, trigger và danh mục cố định. Không chạy lại trên schema đã tồn tại; không DROP/TRUNCATE để khắc phục lỗi. Sau import, chạy lại script kiểm tra và `/health/db` để đối chiếu.

`/health/db` trả database/schema, số bảng và khóa ngoại; HTTP 503 với `not_initialized` khi schema thiếu hoặc rỗng, HTTP 200 khi schema có bảng. Đây là health kết nối/cấu trúc tổng quát, không chứng nhận mọi bảng nghiệp vụ đã đầy đủ. Không trả mật khẩu, hash, host, user hay danh sách tài khoản. SQL xác thực kiểm tra metadata bảng trước khi truy vấn; thiếu bảng trả 503.

Mã và cột theo SQL tham chiếu:

| CSDL | Ứng dụng | Giao diện |
| --- | --- | --- |
| `KHACH_HANG` | `customer` | Khách hàng |
| `NHAN_VIEN` | `staff` | Nhân viên hỗ trợ |
| `QUAN_TRI_VIEN` | `manager` | Quản lý |

Tài khoản dùng `nguoi_dung.nd_ma`, `ho_ten`, `email`, `mat_khau_hash`, `vai_tro`, `trang_thai`; chỉ `HOAT_DONG` được đăng nhập. Email đối chiếu không phân biệt hoa thường, phù hợp index `lower(email)`. Không sửa enum/mã vai trò hay thêm actor. Bảng phụ của Quản lý vẫn là `quan_tri_vien` để tương thích SQL.

Tạo tài khoản Quản lý **chỉ khi chủ động yêu cầu**, sau khi schema được khởi tạo:

```powershell
.\.venv\Scripts\python.exe -X utf8 scripts/create_manager.py --execute
```

Script hỏi họ tên, email, mật khẩu ẩn (tối thiểu 12 ký tự), lưu Argon2id, thêm `nguoi_dung` và bảng phụ trong một transaction. Không có tài khoản/mật khẩu mặc định. Có thể nhận `MANAGER_NAME`, `MANAGER_EMAIL`, `MANAGER_PASSWORD` từ process env cục bộ; không đưa mật khẩu vào dòng lệnh hoặc Git. Email trùng sẽ rollback, không đổi tài khoản cũ. Script không tạo schema, bảng hoặc role.

## API và phiên

| Method | Endpoint | Hành vi |
| --- | --- | --- |
| GET | `/` | Giữ phản hồi Backend đang chạy |
| GET | `/health/db` | Kiểm tra schema cấu hình |
| POST | `/api/v1/auth/login` | Body `{email,password}`, cookie HttpOnly và thông tin người dùng + CSRF token |
| GET | `/api/v1/auth/me` | Thông tin tài khoản thật, kiểm tra lại trạng thái/vai trò từ CSDL |
| GET | `/api/v1/auth/csrf` | Đọc CSRF token cho phiên hiện tại sau reload, không gia hạn hoặc đổi phiên |
| POST | `/api/v1/auth/logout` | Yêu cầu Origin hợp lệ + `X-CSRF-Token`, xóa cookie, 204 |
| GET | `/api/v1/customer/dashboard` | Chỉ Khách hàng |
| GET | `/api/v1/staff/dashboard` | Chỉ Nhân viên hỗ trợ |
| GET | `/api/v1/manager/dashboard` | Chỉ Quản lý |

Cookie có `HttpOnly`, `SameSite=Lax`, path `/api/v1`, thời hạn cố định; JWT HS256 kiểm tra chữ ký, issuer, audience và expiry. Không trả JWT ra response body hoặc lưu localStorage. Mỗi request bảo vệ đọc lại tài khoản, nên khóa tài khoản/đổi vai trò có hiệu lực với request tiếp theo. Argon2id là định dạng tạo mới; hỗ trợ kiểm tra bcrypt có sẵn, không tự đổi hash và không so sánh mật khẩu rõ. Response validation không phản chiếu password nhập vào. Thông báo đăng nhập không phân biệt tài khoản không tồn tại/bị khóa. Có giới hạn 10 lần đăng nhập/phút/IP trong một process.

Đăng xuất hiện là xóa cookie phía client theo cơ chế JWT stateless. Bản sao token đã bị lấy trước đó còn hiệu lực tới expiry; chưa có danh sách thu hồi token phía server. Không có refresh token hoặc ghi nhớ dài hạn. Triển khai nhiều worker cần rate limiter dùng chung/gateway; không tin `X-Forwarded-For` từ client tự gửi.

Triển khai production nên phục vụ frontend và `/api` cùng origin qua reverse proxy HTTPS, `COOKIE_SECURE=true`, origin chính xác (không wildcard), và cấu hình SPA fallback về index.html. Thiết kế hiện dành cho cùng site; không tự bật cookie cross-site. Không đưa secret vào các biến Vite.

## Route giao diện

| Route | Nội dung |
| --- | --- |
| `/` | Trang chủ công khai; hero, tính năng dự kiến, quy trình, FAQ, footer |
| `/login` | Form nối API thật; chưa hỗ trợ ghi nhớ/khôi phục mật khẩu |
| `/customer`, `/staff`, `/manager` | Dashboard theo vai trò, thông tin thật, chưa có số liệu nghiệp vụ |
| `/support/new`, `/support/lookup` | Yêu cầu đăng nhập, sau đó thông báo Đang phát triển |
| Các đường dẫn khác | Trang 404 |

Frontend và backend đều kiểm tra quyền. Sai vai trò hiển thị không đủ quyền; API trả 403. Không xác thực trả 401. Không dùng mock đăng nhập trong frontend. Dữ liệu ticket trên trang chủ được gắn nhãn minh họa, không được lấy làm dữ liệu dashboard. Không triển khai chatbot mặc dù bản thiết kế có khu vực chatbot.

## Kiểm thử

```powershell
# Tại thư mục gốc
.\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -v
# Tại frontend/, backend phải đang chạy
npx playwright install chromium
npm run test:e2e
```

Kiểm thử PostgreSQL và UI với tài khoản tạm (chỉ chạy khi đồng ý tạo bản ghi thử và rollback), tại thư mục gốc:

```powershell
.\.venv\Scripts\python.exe -X utf8 scripts/test_auth_database.py --execute --browser
```

Lệnh này dùng SQL/password verification thật. Connection factory của backend kiểm thử được gắn vào một transaction rollback để frontend nhìn thấy tài khoản chưa commit; không giả lập kết quả truy vấn hoặc login. Backend kiểm thử tạm chạy ở 8001, Vite chế độ `database-test` ở 5174, không thay backend/frontend thường ở 8000/5173. Mật khẩu ngẫu nhiên chỉ chuyển trong bộ nhớ/process env, không ghi vào repo hay ảnh/trace. Lệnh không để lại tài khoản, nhưng identity sequence PostgreSQL có thể tăng. Đã thực thi với sự đồng ý của người dùng: các ca API và 6 ca UI cho ba vai trò PASS, xác nhận lại 0 tài khoản tồn tại sau rollback.

Chi tiết kết quả, phạm vi thật/giả lập và các bước chưa chạy: `docs/PHASE1_TEST_RESULTS.md`.

## File thêm / sửa

- Sửa: `main.py`, `core/database.py`, `.gitignore`, `requirements.txt` (chuyển UTF-16 sang UTF-8 để dễ quản lý; giữ các dependency cũ và bổ sung psycopg 3, Argon2, HTTP client).
- Backend mới: `core/security.py`, `schemas/auth.py`, `services/auth_service.py`, `api/routes/auth.py`, `.env.example`.
- Script và test: `scripts/inspect_database.py`, `scripts/initialize_database.py`, `scripts/create_manager.py`, `scripts/test_auth_database.py`, `tests/test_auth.py`.
- Frontend: `frontend/package.json`, `package-lock.json`, `tsconfig.json`, `vite.config.ts`, `index.html`, `src/main.tsx`, `src/App.tsx`, `src/api.ts`, `src/auth.tsx`, `src/components.tsx`, `src/styles.css`, `src/pages/Home.tsx`, `Login.tsx`, `Dashboard.tsx`, `playwright.config.ts`, `playwright.database.config.ts`, `tests/navigation.spec.ts`, `database-tests/auth.spec.ts`.
- Tài liệu mới: `README.md`, `docs/PHASE1_TEST_RESULTS.md`. `.env` chỉ cập nhật cục bộ, không vào Git. Không sửa SQL và các bản thiết kế người dùng cung cấp.

## Vấn đề nghiệp vụ và công việc tiếp theo

- Đã import SQL vào DB_HELPDESK theo xác nhận. Không chạy lại script khởi tạo; script có kiểm tra từ chối khi database đã có đối tượng ứng dụng.
- Không để lại tài khoản thử hoặc tài khoản sử dụng mặc định. Muốn tự đăng nhập, chủ động chạy script tạo Quản lý với thông tin phù hợp.
- Nhãn “Nhân viên quản lý” trong use case Nhân viên hỗ trợ được đối chiếu với Quản lý; không tạo vai trò thứ tư.
- Use case Quản lý có lọc theo địa phương; SQL hiện không có cột địa phương. Ghi nhận mâu thuẫn, chưa thêm bảng/cột.
- SQL có dữ liệu/khung chatbot và trạng thái DA_HUY; không suy ra yêu cầu triển khai chatbot hoặc nghiệp vụ hủy phiếu ở Giai đoạn 1.
- CRUD, chuyển phiếu, SLA tự động, dashboard nghiệp vụ, báo cáo, khôi phục mật khẩu và ghi nhớ đăng nhập thuộc giai đoạn sau.
